//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package org.spongepowered.asm.lib.util;

import java.util.*;
import org.spongepowered.asm.lib.*;

public interface Textifiable
{
    void textify(final StringBuffer p0, final Map<Label, String> p1);
}
