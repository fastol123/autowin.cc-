//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package org.json.simple;

import java.io.*;

public interface JSONStreamAware
{
    void writeJSONString(final Writer p0) throws IOException;
}
