//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin;

import net.minecraftforge.fml.common.*;
import hi.autowin.manager.*;
import org.lwjgl.opengl.*;
import net.minecraftforge.fml.common.event.*;
import org.apache.logging.log4j.*;

@Mod(modid = "autowin", name = "Autowin", version = "v2")
public class Autowin
{
    public static final String MODID = "autowin";
    public static final String MODNAME = "Autowin";
    public static final String MODVER = "v2";
    public static final Logger LOGGER;
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static TotemPopManager totemPopManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    @Mod.Instance
    public static Autowin INSTANCE;
    private static boolean unloaded;
    
    public static void load() {
        Autowin.LOGGER.info("\n\nLoading Autowin");
        Autowin.unloaded = false;
        if (Autowin.reloadManager != null) {
            Autowin.reloadManager.unload();
            Autowin.totemPopManager.init();
            Autowin.reloadManager = null;
        }
        Autowin.textManager = new TextManager();
        Autowin.totemPopManager = new TotemPopManager();
        Autowin.commandManager = new CommandManager();
        Autowin.friendManager = new FriendManager();
        Autowin.moduleManager = new ModuleManager();
        Autowin.rotationManager = new RotationManager();
        Autowin.packetManager = new PacketManager();
        Autowin.eventManager = new EventManager();
        Autowin.speedManager = new SpeedManager();
        Autowin.potionManager = new PotionManager();
        Autowin.inventoryManager = new InventoryManager();
        Autowin.serverManager = new ServerManager();
        Autowin.fileManager = new FileManager();
        Autowin.colorManager = new ColorManager();
        Autowin.positionManager = new PositionManager();
        Autowin.configManager = new ConfigManager();
        Autowin.holeManager = new HoleManager();
        Autowin.LOGGER.info("Managers loaded.");
        Autowin.moduleManager.init();
        Autowin.LOGGER.info("Modules loaded.");
        Autowin.configManager.init();
        Autowin.eventManager.init();
        Autowin.LOGGER.info("EventManager loaded.");
        Autowin.textManager.init(true);
        Autowin.moduleManager.onLoad();
        Autowin.LOGGER.info("Autowin successfully loaded!\n");
    }
    
    public static void unload(final boolean unload) {
        Autowin.LOGGER.info("\n\nUnloading Autowin");
        if (unload) {
            (Autowin.reloadManager = new ReloadManager()).init((Autowin.commandManager != null) ? Autowin.commandManager.getPrefix() : "");
        }
        onUnload();
        Autowin.eventManager = null;
        Autowin.friendManager = null;
        Autowin.speedManager = null;
        Autowin.holeManager = null;
        Autowin.positionManager = null;
        Autowin.rotationManager = null;
        Autowin.configManager = null;
        Autowin.commandManager = null;
        Autowin.colorManager = null;
        Autowin.totemPopManager = null;
        Autowin.serverManager = null;
        Autowin.fileManager = null;
        Autowin.potionManager = null;
        Autowin.inventoryManager = null;
        Autowin.moduleManager = null;
        Autowin.textManager = null;
        Autowin.LOGGER.info("Autowin unloaded!\n");
    }
    
    public static void reload() {
        unload(false);
        load();
    }
    
    public static void onUnload() {
        if (!Autowin.unloaded) {
            Autowin.eventManager.onUnload();
            Autowin.moduleManager.onUnload();
            Autowin.configManager.saveConfig(Autowin.configManager.config.replaceFirst("autowin/", ""));
            Autowin.moduleManager.onUnloadPost();
            Autowin.unloaded = true;
        }
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent event) {
        Display.setTitle("launching autowin v2");
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        Display.setTitle("autowin v2");
        load();
    }
    
    static {
        LOGGER = LogManager.getLogger("Autowin");
        Autowin.unloaded = false;
    }
}
