//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.manager;

import hi.autowin.features.*;
import net.minecraft.entity.player.*;
import hi.autowin.features.modules.client.*;
import java.util.concurrent.*;
import hi.autowin.features.command.*;
import java.util.*;
import hi.autowin.*;
import java.util.function.*;

public class TotemPopManager extends Feature
{
    private final Set<EntityPlayer> toAnnounce;
    private Notifications notifications;
    private Map<EntityPlayer, Integer> poplist;
    
    public TotemPopManager() {
        this.toAnnounce = new HashSet<EntityPlayer>();
        this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
    }
    
    public void onUpdate() {
        if (this.notifications.totemAnnounce.passedMs((int)this.notifications.delay.getValue()) && this.notifications.isOn() && (boolean)this.notifications.totemPops.getValue()) {
            for (final EntityPlayer player : this.toAnnounce) {
                if (player == null) {
                    continue;
                }
                Command.sendMessage("�c" + player.getName() + " popped " + "�a" + this.getTotemPops(player) + "�c" + " Totem" + ((this.getTotemPops(player) == 1) ? "" : "s") + ".");
                this.toAnnounce.remove(player);
                this.notifications.totemAnnounce.reset();
                break;
            }
        }
    }
    
    public void onLogout() {
        this.onOwnLogout((boolean)this.notifications.clearOnLogout.getValue());
    }
    
    public void init() {
        this.notifications = (Notifications)Autowin.moduleManager.getModuleByClass((Class)Notifications.class);
    }
    
    public void onTotemPop(final EntityPlayer player) {
        this.popTotem(player);
        if (!player.equals((Object)TotemPopManager.mc.player)) {
            this.toAnnounce.add(player);
            this.notifications.totemAnnounce.reset();
        }
    }
    
    public void onDeath(final EntityPlayer player) {
        if (this.getTotemPops(player) != 0 && !player.equals((Object)TotemPopManager.mc.player) && this.notifications.isOn() && (boolean)this.notifications.totemPops.getValue()) {
            Command.sendMessage("�c" + player.getName() + " died after popping " + "�a" + this.getTotemPops(player) + "�c" + " Totem" + ((this.getTotemPops(player) == 1) ? "" : "s") + ".");
            this.toAnnounce.remove(player);
        }
        this.resetPops(player);
    }
    
    public void onLogout(final EntityPlayer player, final boolean clearOnLogout) {
        if (clearOnLogout) {
            this.resetPops(player);
        }
    }
    
    public void onOwnLogout(final boolean clearOnLogout) {
        if (clearOnLogout) {
            this.clearList();
        }
    }
    
    public void clearList() {
        this.poplist = new ConcurrentHashMap<EntityPlayer, Integer>();
    }
    
    public void resetPops(final EntityPlayer player) {
        this.setTotemPops(player, 0);
    }
    
    public void popTotem(final EntityPlayer player) {
        this.poplist.merge(player, 1, Integer::sum);
    }
    
    public void setTotemPops(final EntityPlayer player, final int amount) {
        this.poplist.put(player, amount);
    }
    
    public int getTotemPops(final EntityPlayer player) {
        final Integer pops = this.poplist.get(player);
        if (pops == null) {
            return 0;
        }
        return pops;
    }
    
    public String getTotemPopString(final EntityPlayer player) {
        return "�f" + ((this.getTotemPops(player) <= 0) ? "" : ("-" + this.getTotemPops(player) + " "));
    }
}
