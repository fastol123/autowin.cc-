//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util;

import net.minecraft.client.*;

public interface Util
{
    public static final Minecraft mc = Minecraft.getMinecraft();
}
