//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util.Render;

import java.awt.*;
import org.lwjgl.opengl.*;
import hi.autowin.features.modules.client.*;

public abstract class ColorUtil
{
    public static int toARGB(final int r, final int g, final int b, final int a) {
        return new Color(r, g, b, a).getRGB();
    }
    
    public static int HSBtoRGB(final float h, final float s, final float b) {
        return Color.HSBtoRGB(h, s, b);
    }
    
    public static Color alpha(final Color color, final int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
    
    public static int GenRainbow() {
        final float[] hue = { System.currentTimeMillis() % 11520L / 11520.0f };
        final int rgb = Color.HSBtoRGB(hue[0], 1.0f, 1.0f);
        final int red = rgb >> 16 & 0xFF;
        final int green = rgb >> 8 & 0xFF;
        final int blue = rgb & 0xFF;
        final int color = toRGBA(red, green, blue, 255);
        return color;
    }
    
    public static int staticRainbow(final float offset, final Color color) {
        final double timer = System.currentTimeMillis() % 1750.0 / 850.0;
        final float[] hsb = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
        final float brightness = (float)(hsb[2] * Math.abs((offset + timer) % 1.0 - 0.550000011920929) + 0.44999998807907104);
        return Color.HSBtoRGB(hsb[0], hsb[1], brightness);
    }
    
    public static int toRGBA(final double r, final double g, final double b, final double a) {
        return toRGBA((float)r, (float)g, (float)b, (float)a);
    }
    
    public static int toRGBA(final int r, final int g, final int b) {
        return toRGBA(r, g, b, 255);
    }
    
    public static int toRGBA(final int r, final int g, final int b, final int a) {
        return (r << 16) + (g << 8) + b + (a << 24);
    }
    
    public static int toRGBA(final float r, final float g, final float b, final float a) {
        return toRGBA((int)(r * 255.0f), (int)(g * 255.0f), (int)(b * 255.0f), (int)(a * 255.0f));
    }
    
    public static void glColor(final Color color) {
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
    }
    
    public static int getRainbow(final int speed, final float s, final int i) {
        final float hue = (float)(System.currentTimeMillis() % speed);
        return Color.getHSBColor(hue / speed, s, 1.0f).getRGB();
    }
    
    public static Color rainbow(final int delay) {
        double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        return Color.getHSBColor((float)((rainbowState %= 360.0) / 360.0), (float)ClickGui.getInstance().rainbowSaturation.getValue() / 255.0f, (float)ClickGui.getInstance().rainbowBrightness.getValue() / 255.0f);
    }
    
    public static Color newAlpha(final Color color, final int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
    
    public static int toRGBA(final float[] colors) {
        if (colors.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return toRGBA(colors[0], colors[1], colors[2], colors[3]);
    }
    
    public static int toRGBA(final double[] colors) {
        if (colors.length != 4) {
            throw new IllegalArgumentException("colors[] must have a length of 4!");
        }
        return toRGBA((float)colors[0], (float)colors[1], (float)colors[2], (float)colors[3]);
    }
    
    public static int toRGBA(final Color color) {
        return toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }
    
    public abstract static class Colors
    {
        public static final int WHITE;
        public static final int BLACK;
        public static final int RED;
        public static final int GREEN;
        public static final int BLUE;
        public static final int ORANGE;
        public static final int PURPLE;
        public static final int GRAY;
        public static final int DARK_RED;
        public static final int YELLOW;
        public static final int PINK;
        public static final int RAINBOW = Integer.MIN_VALUE;
        
        static {
            WHITE = ColorUtil.toRGBA(255, 255, 255, 155);
            BLACK = ColorUtil.toRGBA(0, 0, 0, 155);
            RED = ColorUtil.toRGBA(255, 0, 0, 155);
            GREEN = ColorUtil.toRGBA(0, 255, 0, 155);
            BLUE = ColorUtil.toRGBA(0, 0, 255, 155);
            ORANGE = ColorUtil.toRGBA(255, 128, 0, 100);
            PURPLE = ColorUtil.toRGBA(105, 13, 173, 100);
            GRAY = ColorUtil.toRGBA(169, 169, 169, 155);
            DARK_RED = ColorUtil.toRGBA(64, 0, 0, 155);
            YELLOW = ColorUtil.toRGBA(255, 255, 0, 155);
            PINK = ColorUtil.toRGBA(255, 120, 203, 100);
        }
    }
}
