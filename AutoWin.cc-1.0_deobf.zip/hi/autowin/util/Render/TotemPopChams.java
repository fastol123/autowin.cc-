//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util.Render;

import net.minecraft.client.*;
import net.minecraft.client.entity.*;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.*;
import net.minecraftforge.client.event.*;
import org.lwjgl.opengl.*;
import hi.autowin.features.modules.render.*;
import java.awt.*;
import net.minecraft.util.math.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.common.*;

public class TotemPopChams
{
    private static final Minecraft mc;
    final ModelPlayer playerModel;
    final EntityOtherPlayerMP player;
    final Long startTime;
    double alphaFill;
    double alphaLine;
    
    public static float interpolateRotation(final float f, final float f2, final float f3) {
        float f4;
        for (f4 = f2 - f; f4 < -180.0f; f4 += 360.0f) {}
        while (f4 >= 180.0f) {
            f4 -= 360.0f;
        }
        return f + f3 * f4;
    }
    
    public static void renderEntity(final EntityLivingBase entityLivingBase, final ModelBase modelBase, final float f, final float f2, final float f3, final float f4, final float f5, final float f6) {
        if (TotemPopChams.mc.getRenderManager() == null) {
            return;
        }
        final float f7 = TotemPopChams.mc.getRenderPartialTicks();
        final double d = entityLivingBase.posX - TotemPopChams.mc.getRenderManager().viewerPosX;
        double d2 = entityLivingBase.posY - TotemPopChams.mc.getRenderManager().viewerPosY;
        final double d3 = entityLivingBase.posZ - TotemPopChams.mc.getRenderManager().viewerPosZ;
        GlStateManager.pushMatrix();
        if (entityLivingBase.isSneaking()) {
            d2 -= 0.125;
        }
        final float f8 = interpolateRotation(entityLivingBase.prevRenderYawOffset, entityLivingBase.renderYawOffset, f7);
        final float f9 = interpolateRotation(entityLivingBase.prevRotationYawHead, entityLivingBase.rotationYawHead, f7);
        final float f10 = f9 - f8;
        final float f11 = entityLivingBase.prevRotationPitch + (entityLivingBase.rotationPitch - entityLivingBase.prevRotationPitch) * f7;
        renderLivingAt(d, d2, d3);
        final float f12 = handleRotationFloat(entityLivingBase, f7);
        prepareRotations(entityLivingBase);
        final float f13 = prepareScale(entityLivingBase, f6);
        GlStateManager.enableAlpha();
        modelBase.setLivingAnimations(entityLivingBase, f, f2, f7);
        modelBase.setRotationAngles(f, f2, f12, entityLivingBase.rotationYawHead, entityLivingBase.rotationPitch, f13, (Entity)entityLivingBase);
        modelBase.render((Entity)entityLivingBase, f, f2, f12, entityLivingBase.rotationYawHead, entityLivingBase.rotationPitch, f13);
        GlStateManager.popMatrix();
    }
    
    public static void renderLivingAt(final double d, final double d2, final double d3) {
        GlStateManager.translate((float)d, (float)d2, (float)d3);
    }
    
    @SubscribeEvent
    public void onRenderWorld(final RenderWorldLastEvent renderWorldLastEvent) {
        if (this.player == null || TotemPopChams.mc.world == null || TotemPopChams.mc.player == null) {
            return;
        }
        GL11.glLineWidth(1.0f);
        final Color color = new Color((int)PopChams.rL.getValue(), (int)PopChams.gL.getValue(), (int)PopChams.bL.getValue(), (int)PopChams.aL.getValue());
        final Color color2 = new Color((int)PopChams.rF.getValue(), (int)PopChams.gF.getValue(), (int)PopChams.bF.getValue(), (int)PopChams.aF.getValue());
        int n = color.getAlpha();
        int n2 = color2.getAlpha();
        final long l = System.currentTimeMillis() - this.startTime - (long)PopChams.fadestart.getValue();
        if (System.currentTimeMillis() - this.startTime > (long)PopChams.fadestart.getValue()) {
            double d = this.normalize((double)l, (double)PopChams.fadetime.getValue());
            d = MathHelper.clamp(d, 0.0, 1.0);
            d = -d + 1.0;
            n *= (int)d;
            n2 *= (int)d;
        }
        final Color color3 = newAlpha(color, n);
        final Color color4 = newAlpha(color2, n2);
        if (this.player != null && this.playerModel != null) {
            PopChams.prepareGL();
            GL11.glPushAttrib(1048575);
            GL11.glEnable(2881);
            GL11.glEnable(2848);
            if (this.alphaFill > 1.0) {
                this.alphaFill -= (float)PopChams.fadetime.getValue();
            }
            final Color color5 = new Color(color4.getRed(), color4.getGreen(), color4.getBlue(), (int)this.alphaFill);
            if (this.alphaLine > 1.0) {
                this.alphaLine -= (float)PopChams.fadetime.getValue();
            }
            final Color color6 = new Color(color3.getRed(), color3.getGreen(), color3.getBlue(), (int)this.alphaLine);
            glColor(color5);
            GL11.glPolygonMode(1032, 6914);
            renderEntity((EntityLivingBase)this.player, (ModelBase)this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, (float)this.player.ticksExisted, this.player.rotationYawHead, this.player.rotationPitch, 1.0f);
            glColor(color6);
            GL11.glPolygonMode(1032, 6913);
            renderEntity((EntityLivingBase)this.player, (ModelBase)this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, (float)this.player.ticksExisted, this.player.rotationYawHead, this.player.rotationPitch, 1.0f);
            GL11.glPolygonMode(1032, 6914);
            GL11.glPopAttrib();
            PopChams.releaseGL();
        }
    }
    
    public static void prepareRotations(final EntityLivingBase entityLivingBase) {
        GlStateManager.rotate(180.0f - entityLivingBase.rotationYaw, 0.0f, 1.0f, 0.0f);
    }
    
    public static Color newAlpha(final Color color, final int n) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
    }
    
    public static float prepareScale(final EntityLivingBase entityLivingBase, final float f) {
        GlStateManager.enableRescaleNormal();
        GlStateManager.scale(-1.0f, -1.0f, 1.0f);
        final double d = entityLivingBase.getRenderBoundingBox().maxX - entityLivingBase.getRenderBoundingBox().minX;
        final double d2 = entityLivingBase.getRenderBoundingBox().maxZ - entityLivingBase.getRenderBoundingBox().minZ;
        GlStateManager.scale(f + d, (double)(f * entityLivingBase.height), f + d2);
        final float f2 = 0.0625f;
        GlStateManager.translate(0.0f, -1.501f, 0.0f);
        return 0.0625f;
    }
    
    public static void prepareTranslate(final EntityLivingBase entityLivingBase, final double d, final double d2, final double d3) {
        renderLivingAt(d - TotemPopChams.mc.getRenderManager().viewerPosX, d2 - TotemPopChams.mc.getRenderManager().viewerPosY, d3 - TotemPopChams.mc.getRenderManager().viewerPosZ);
    }
    
    public static float handleRotationFloat(final EntityLivingBase entityLivingBase, final float f) {
        return 0.0f;
    }
    
    public TotemPopChams(final EntityOtherPlayerMP entityOtherPlayerMP, final ModelPlayer modelPlayer, final Long l, final double d, final double d2) {
        MinecraftForge.EVENT_BUS.register((Object)this);
        this.player = entityOtherPlayerMP;
        this.playerModel = modelPlayer;
        this.startTime = l;
        this.alphaFill = d;
        this.alphaLine = d;
    }
    
    public static void glColor(final Color color) {
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
    }
    
    double normalize(final double d, final double d2) {
        return (d - 0.0) / (d2 - 0.0);
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
}
