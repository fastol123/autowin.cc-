//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util.misc;

import hi.autowin.util.mc.*;
import java.util.concurrent.atomic.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.enchantment.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

public class InventoryUtil2 implements MC
{
    public static void switchToHotbarSlot(final Class clazz, final boolean bl) {
        final int n = findHotbarBlock(clazz);
        if (n > -1) {
            switchToHotbarSlot(n, bl);
        }
    }
    
    public static int findItemInventorySlot(final Item item, final boolean bl) {
        final AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(-1);
        for (final Map.Entry<Integer, ItemStack> entry : getInventoryAndHotbarSlots().entrySet()) {
            if (entry.getValue().getItem() != item) {
                continue;
            }
            if (entry.getKey() == 45 && !bl) {
                continue;
            }
            atomicInteger.set(entry.getKey());
            return atomicInteger.get();
        }
        return atomicInteger.get();
    }
    
    public static boolean isNull(final ItemStack itemStack) {
        return itemStack == null || itemStack.getItem() instanceof ItemAir;
    }
    
    public static boolean isInstanceOf(final ItemStack itemStack, final Class clazz) {
        if (itemStack == null) {
            return false;
        }
        final Item item = itemStack.getItem();
        if (clazz.isInstance(item)) {
            return true;
        }
        if (item instanceof ItemBlock) {
            final Block block = Block.getBlockFromItem(item);
            return clazz.isInstance(block);
        }
        return false;
    }
    
    public static int findArmorSlot(final EntityEquipmentSlot entityEquipmentSlot, final boolean bl) {
        int n = -1;
        float f = 0.0f;
        for (int i = 9; i < 45; ++i) {
            boolean bl2 = false;
            final ItemStack itemStack = InventoryUtil2.mc.player.inventoryContainer.getSlot(i).getStack();
            if (itemStack.getItem() != Items.AIR && itemStack.getItem() instanceof ItemArmor) {
                final ItemArmor itemArmor;
                if ((itemArmor = (ItemArmor)itemStack.getItem()).getEquipmentSlot() == entityEquipmentSlot) {
                    final float f2 = (float)(itemArmor.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, itemStack));
                    final boolean bl3 = (bl && EnchantmentHelper.hasBindingCurse(itemStack)) || (bl2 = false);
                    if (f2 > f) {
                        if (!bl2) {
                            f = f2;
                            n = i;
                        }
                    }
                }
            }
        }
        return n;
    }
    
    public static List<Integer> findEmptySlots(final boolean bl) {
        final ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (final Map.Entry<Integer, ItemStack> slot : getInventoryAndHotbarSlots().entrySet()) {
            if (!slot.getValue().isEmpty() && slot.getValue().getItem() != Items.AIR) {
                continue;
            }
            arrayList.add(slot.getKey());
        }
        if (bl) {
            for (int i = 1; i < 5; ++i) {
                final Slot slot2 = InventoryUtil2.mc.player.inventoryContainer.inventorySlots.get(i);
                final ItemStack itemStack = slot2.getStack();
                if (itemStack.isEmpty() || itemStack.getItem() == Items.AIR) {
                    arrayList.add(i);
                }
            }
        }
        return arrayList;
    }
    
    public static int getItemHotbars(final Item item) {
        for (int i = 0; i < 36; ++i) {
            final Item item2 = InventoryUtil2.mc.player.inventory.getStackInSlot(i).getItem();
            if (Item.getIdFromItem(item2) == Item.getIdFromItem(item)) {
                return i;
            }
        }
        return -1;
    }
    
    public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        return getInventorySlots();
    }
    
    public static boolean isBlock(final Item item, final Class clazz) {
        if (item instanceof ItemBlock) {
            final Block block = ((ItemBlock)item).getBlock();
            return clazz.isInstance(block);
        }
        return false;
    }
    
    public static int findItemInHotbar(final Item item) {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            if (InventoryUtil2.mc.player.inventory.getStackInSlot(i).getItem() == item) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    public static int findHotbarBlock(final Block block) {
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = InventoryUtil2.mc.player.inventory.getStackInSlot(i);
            if (itemStack != ItemStack.EMPTY) {
                if (itemStack.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)itemStack.getItem()).getBlock() == block) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }
    
    public static void switchToHotbarSlot(final int n, final boolean bl) {
        if (InventoryUtil2.mc.player.inventory.currentItem == n || n < 0) {
            return;
        }
        if (bl) {
            InventoryUtil2.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(n));
            InventoryUtil2.mc.playerController.updateController();
        }
        else {
            InventoryUtil2.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(n));
            InventoryUtil2.mc.player.inventory.currentItem = n;
            InventoryUtil2.mc.playerController.updateController();
        }
    }
    
    public static int getItemDurability(final ItemStack itemStack) {
        if (itemStack == null) {
            return 0;
        }
        return itemStack.getMaxDamage() - itemStack.getItemDamage();
    }
    
    public static int getEmptyXCarry() {
        for (int i = 1; i < 5; ++i) {
            final Slot slot = InventoryUtil2.mc.player.inventoryContainer.inventorySlots.get(i);
            final ItemStack itemStack = slot.getStack();
            if (itemStack.isEmpty() || itemStack.getItem() == Items.AIR) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean holdingItem(final Class clazz) {
        final ItemStack itemStack = InventoryUtil2.mc.player.getHeldItemMainhand();
        boolean bl = isInstanceOf(itemStack, clazz);
        if (!bl) {
            bl = isInstanceOf(itemStack, clazz);
        }
        return bl;
    }
    
    public static int findArmorSlot(final EntityEquipmentSlot entityEquipmentSlot, final boolean bl, final boolean bl2) {
        int n = findArmorSlot(entityEquipmentSlot, bl);
        if (n == -1 && bl2) {
            float f = 0.0f;
            for (int i = 1; i < 5; ++i) {
                boolean bl3 = false;
                final Slot slot = InventoryUtil2.mc.player.inventoryContainer.inventorySlots.get(i);
                final ItemStack itemStack = slot.getStack();
                if (itemStack.getItem() != Items.AIR && itemStack.getItem() instanceof ItemArmor) {
                    final ItemArmor itemArmor;
                    if ((itemArmor = (ItemArmor)itemStack.getItem()).getEquipmentSlot() == entityEquipmentSlot) {
                        final float f2 = (float)(itemArmor.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, itemStack));
                        final boolean bl4 = (bl && EnchantmentHelper.hasBindingCurse(itemStack)) || (bl3 = false);
                        if (f2 > f) {
                            if (!bl3) {
                                f = f2;
                                n = i;
                            }
                        }
                    }
                }
            }
        }
        return n;
    }
    
    private static Map<Integer, ItemStack> getInventorySlots() {
        final HashMap<Integer, ItemStack> hashMap = new HashMap<Integer, ItemStack>();
        for (int i = 9; i <= 44; ++i) {
            hashMap.put(i, (ItemStack)InventoryUtil2.mc.player.inventoryContainer.getInventory().get(i));
        }
        return hashMap;
    }
    
    public static int findItemInventorySlot(final Item item, final boolean bl, final boolean bl2) {
        int n = findItemInventorySlot(item, bl);
        if (n == -1 && bl2) {
            for (int i = 1; i < 5; ++i) {
                final Slot slot = InventoryUtil2.mc.player.inventoryContainer.inventorySlots.get(i);
                final ItemStack itemStack = slot.getStack();
                if (itemStack.getItem() != Items.AIR && itemStack.getItem() == item) {
                    n = i;
                }
            }
        }
        return n;
    }
    
    public static int findAnyBlock() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = InventoryUtil2.mc.player.inventory.getStackInSlot(i);
            if (itemStack != ItemStack.EMPTY && itemStack.getItem() instanceof ItemBlock) {
                return i;
            }
        }
        return -1;
    }
    
    public static void switchToItem(final Item item) {
        final int n = getItemHotbar(item);
        if (n == -1) {
            return;
        }
        switchToHotbarSlot(n, false);
    }
    
    public static int getItemHotbar(final Item item) {
        for (int i = 0; i < 9; ++i) {
            final Item item2 = InventoryUtil2.mc.player.inventory.getStackInSlot(i).getItem();
            if (Item.getIdFromItem(item2) == Item.getIdFromItem(item)) {
                return i;
            }
        }
        return -1;
    }
    
    public static void switchToSlot(final int n) {
        if (InventoryUtil2.mc.player.inventory.currentItem == n || n < 0) {
            return;
        }
        InventoryUtil2.mc.player.inventory.currentItem = n;
        InventoryUtil2.mc.playerController.updateController();
    }
    
    public static int pickItem(final int n) {
        final ArrayList<Object> arrayList = new ArrayList<Object>();
        for (int i = 0; i < 9; ++i) {
            if (Item.getIdFromItem(((ItemStack)InventoryUtil2.mc.player.inventory.mainInventory.get(i)).getItem()) == n) {
                arrayList.add(InventoryUtil2.mc.player.inventory.mainInventory.get(i));
            }
        }
        if (arrayList.size() >= 1) {
            return InventoryUtil2.mc.player.inventory.mainInventory.indexOf(arrayList.get(0));
        }
        return -1;
    }
    
    public static int findPistonBlock() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = InventoryUtil2.mc.player.inventory.getStackInSlot(i);
            if (itemStack != ItemStack.EMPTY) {
                if (itemStack.getItem() instanceof ItemBlock) {
                    if (((ItemBlock)itemStack.getItem()).getBlock() instanceof BlockPistonBase) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }
    
    public static int findHotbarBlock(final Class clazz) {
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = InventoryUtil2.mc.player.inventory.getStackInSlot(i);
            if (itemStack != ItemStack.EMPTY) {
                if (clazz.isInstance(itemStack.getItem())) {
                    return i;
                }
                if (itemStack.getItem() instanceof ItemBlock) {
                    if (clazz.isInstance(((ItemBlock)itemStack.getItem()).getBlock())) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }
    
    public static boolean isSlotEmpty(final int n) {
        final Slot slot = InventoryUtil2.mc.player.inventoryContainer.inventorySlots.get(n);
        final ItemStack itemStack = slot.getStack();
        return itemStack.isEmpty();
    }
    
    public static int findInventoryBlock(final Class clazz, final boolean bl) {
        final AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(-1);
        for (final Map.Entry<Integer, ItemStack> entry : getInventoryAndHotbarSlots().entrySet()) {
            if (!isBlock(entry.getValue().getItem(), clazz)) {
                continue;
            }
            if (entry.getKey() == 45 && !bl) {
                continue;
            }
            atomicInteger.set(entry.getKey());
            return atomicInteger.get();
        }
        return atomicInteger.get();
    }
    
    public static class Task
    {
        private final int slot;
        private final boolean update;
        private final boolean quickClick;
        
        public Task() {
            this.update = true;
            this.slot = -1;
            this.quickClick = false;
        }
        
        public Task(final int n) {
            this.slot = n;
            this.quickClick = false;
            this.update = false;
        }
        
        public void run() {
            if (this.update) {
                MC.mc.playerController.updateController();
            }
            if (this.slot != -1) {
                MC.mc.playerController.windowClick(0, this.slot, 0, this.quickClick ? ClickType.QUICK_MOVE : ClickType.PICKUP, (EntityPlayer)MC.mc.player);
            }
        }
        
        public Task(final int n, final boolean bl) {
            this.slot = n;
            this.quickClick = bl;
            this.update = false;
        }
    }
}
