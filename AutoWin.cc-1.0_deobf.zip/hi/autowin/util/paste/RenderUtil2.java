//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util.paste;

import hi.autowin.util.*;
import net.minecraft.client.gui.*;
import java.awt.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.renderer.*;
import org.lwjgl.opengl.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.vertex.*;

public class RenderUtil2 implements Util
{
    private static final ScaledResolution resolution;
    public static Tessellator tessellator;
    public static BufferBuilder bufferBuilder;
    
    public static void addChainedGlowBoxVertices(final double d, final double d2, final double d3, final double d4, final double d5, final double d6, final Color color, final Color color2) {
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, color2.getAlpha() / 255.0f).endVertex();
    }
    
    public static void glBillboardDistanceScaled(final float f, final float f2, final float f3, final EntityPlayer entityPlayer, final float f4) {
        glBillboard(f, f2, f3);
        final int n = (int)entityPlayer.getDistance((double)f, (double)f2, (double)f3);
        float f5 = n / 2.0f / (2.0f + (2.0f - f4));
        if (f5 < 1.0f) {
            f5 = 1.0f;
        }
        GlStateManager.scale(f5, f5, f5);
    }
    
    public static void addChainedFilledBoxVertices(final double d, final double d2, final double d3, final double d4, final double d5, final double d6, final Color color) {
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
    }
    
    public static void drawLine3D(final Vec3d vec3d, final Vec3d vec3d2, final Color color, final double d) {
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glLineWidth(0.1f);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glLineWidth((float)d);
        GL11.glBegin(1);
        GL11.glVertex3d(vec3d.x, vec3d.y, vec3d.z);
        GL11.glVertex3d(vec3d2.x, vec3d2.y, vec3d2.z);
        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glDisable(2848);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    public static void drawSelectionGlowFilledBox(final AxisAlignedBB axisAlignedBB, final double d, final double d2, final double d3, final Color color, final Color color2) {
        RenderUtil2.bufferBuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
        addChainedGlowBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + d2, axisAlignedBB.maxY + d, axisAlignedBB.maxZ + d3, color, color2);
        RenderUtil2.tessellator.draw();
    }
    
    public static void drawBorder(final float f, final float f2, final float f3, final float f4, final Color color) {
        drawRect(f - 0.5f, f2 - 0.5f, 0.5f, f4 + 1.0f, color);
        drawRect(f + f3, f2 - 0.5f, 0.5f, f4 + 1.0f, color);
        drawRect(f, f2 - 0.5f, f3, 0.5f, color);
        drawRect(f, f2 + f4, f3, 0.5f, color);
    }
    
    public static void drawCircle(final RenderBuilder renderBuilder, final Vec3d vec3d, final double d, final double d2, final Color color) {
        renderCircle(RenderUtil2.bufferBuilder, vec3d, d, d2, color);
        renderBuilder.build();
    }
    
    public static void drawSelectionBoundingBox(final AxisAlignedBB axisAlignedBB, final double d, final double d2, final double d3, final Color color) {
        RenderUtil2.bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
        addChainedBoundingBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + d2, axisAlignedBB.maxY + d, axisAlignedBB.maxZ + d3, color);
        RenderUtil2.tessellator.draw();
    }
    
    public static void drawBox(final RenderBuilder renderBuilder) {
        if (RenderUtil2.mc.getRenderViewEntity() != null) {
            final AxisAlignedBB axisAlignedBB = renderBuilder.getAxisAlignedBB().offset(-RenderUtil2.mc.getRenderManager().viewerPosX, -RenderUtil2.mc.getRenderManager().viewerPosY, -RenderUtil2.mc.getRenderManager().viewerPosZ);
            switch (renderBuilder.getBox()) {
                case FILL: {
                    drawSelectionBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor());
                    break;
                }
                case OUTLINE: {
                    drawSelectionBoundingBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 144));
                    break;
                }
                case BOTH: {
                    drawSelectionBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor());
                    drawSelectionBoundingBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 144));
                    break;
                }
                case GLOW: {
                    drawSelectionGlowFilledBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), renderBuilder.getColor(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 0));
                    break;
                }
                case REVERSE: {
                    drawSelectionGlowFilledBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 0), renderBuilder.getColor());
                    break;
                }
                case CLAW: {
                    drawClawBox(axisAlignedBB, renderBuilder.getHeight(), renderBuilder.getLength(), renderBuilder.getWidth(), new Color(renderBuilder.getColor().getRed(), renderBuilder.getColor().getGreen(), renderBuilder.getColor().getBlue(), 255));
                    break;
                }
            }
            renderBuilder.build();
        }
    }
    
    public static void addChainedBoundingBoxVertices(final double d, final double d2, final double d3, final double d4, final double d5, final double d6, final Color color) {
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
    }
    
    public static void addChainedClawBoxVertices(final double d, final double d2, final double d3, final double d4, final double d5, final double d6, final Color color) {
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6 - 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3 + 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6 - 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3 + 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4 - 0.8, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4 - 0.8, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d + 0.8, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d + 0.8, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2 + 0.2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d2 + 0.2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2 + 0.2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d2 + 0.2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6 - 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3 + 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6 - 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3 + 0.8).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4 - 0.8, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4 - 0.8, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d + 0.8, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d + 0.8, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5 - 0.2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d, d5 - 0.2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d3).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5 - 0.2, d3).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5, d6).color(color.getRed(), color.getGreen(), color.getBlue(), 0).endVertex();
        RenderUtil2.bufferBuilder.pos(d4, d5 - 0.2, d6).color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).endVertex();
    }
    
    public static void drawRoundedRect(double d, double d2, double d3, double d4, final double d5, final Color color) {
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        d3 *= 2.0;
        d4 *= 2.0;
        d3 += (d *= 2.0);
        d4 += (d2 *= 2.0);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glEnable(2848);
        GL11.glBegin(9);
        for (int n = 0; n <= 90; ++n) {
            GL11.glVertex2d(d + d5 + Math.sin(n * 3.141592653589793 / 180.0) * d5 * -1.0, d2 + d5 + Math.cos(n * 3.141592653589793 / 180.0) * d5 * -1.0);
        }
        for (int n = 90; n <= 180; ++n) {
            GL11.glVertex2d(d + d5 + Math.sin(n * 3.141592653589793 / 180.0) * d5 * -1.0, d4 - d5 + Math.cos(n * 3.141592653589793 / 180.0) * d5 * -1.0);
        }
        for (int n = 0; n <= 90; ++n) {
            GL11.glVertex2d(d3 - d5 + Math.sin(n * 3.141592653589793 / 180.0) * d5, d4 - d5 + Math.cos(n * 3.141592653589793 / 180.0) * d5);
        }
        for (int n = 90; n <= 180; ++n) {
            GL11.glVertex2d(d3 - d5 + Math.sin(n * 3.141592653589793 / 180.0) * d5, d2 + d5 + Math.cos(n * 3.141592653589793 / 180.0) * d5);
        }
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glScaled(2.0, 2.0, 2.0);
        GL11.glPopAttrib();
    }
    
    public static void drawClawBox(final AxisAlignedBB axisAlignedBB, final double d, final double d2, final double d3, final Color color) {
        RenderUtil2.bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
        addChainedClawBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + d2, axisAlignedBB.maxY + d, axisAlignedBB.maxZ + d3, color);
        RenderUtil2.tessellator.draw();
    }
    
    public static void drawRect(final float f, final float f2, final float f3, final float f4, final int n) {
        final Color color = new Color(n, true);
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glShadeModel(7425);
        GL11.glBegin(7);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glVertex2f(f, f2);
        GL11.glVertex2f(f, f2 + f4);
        GL11.glVertex2f(f + f3, f2 + f4);
        GL11.glVertex2f(f + f3, f2);
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }
    
    public static void drawRect(final float f, final float f2, final float f3, final float f4, final Color color) {
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glShadeModel(7425);
        GL11.glBegin(7);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        GL11.glVertex2f(f, f2);
        GL11.glVertex2f(f, f2 + f4);
        GL11.glVertex2f(f + f3, f2 + f4);
        GL11.glVertex2f(f + f3, f2);
        GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
        GL11.glEnd();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }
    
    public static double getDisplayWidth() {
        return RenderUtil2.resolution.getScaledWidth_double();
    }
    
    public static double getDisplayHeight() {
        return RenderUtil2.resolution.getScaledHeight_double();
    }
    
    public static void drawSelectionBox(final AxisAlignedBB axisAlignedBB, final double d, final double d2, final double d3, final Color color) {
        RenderUtil2.bufferBuilder.begin(5, DefaultVertexFormats.POSITION_COLOR);
        addChainedFilledBoxVertices(axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ, axisAlignedBB.maxX + d2, axisAlignedBB.maxY + d, axisAlignedBB.maxZ + d3, color);
        RenderUtil2.tessellator.draw();
    }
    
    public static void glBillboard(final float f, final float f2, final float f3) {
        final float f4 = 0.02666667f;
        GlStateManager.translate(f - RenderUtil2.mc.getRenderManager().viewerPosX, f2 - RenderUtil2.mc.getRenderManager().viewerPosY, f3 - RenderUtil2.mc.getRenderManager().viewerPosZ);
        GlStateManager.glNormal3f(0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(-RenderUtil2.mc.player.rotationYaw, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(RenderUtil2.mc.player.rotationPitch, (RenderUtil2.mc.gameSettings.thirdPersonView == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-f4, -f4, f4);
    }
    
    public static void drawPolygon(final double d, final double d2, final float f, final int n, final Color color) {
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
        RenderUtil2.bufferBuilder.begin(6, DefaultVertexFormats.POSITION);
        RenderUtil2.bufferBuilder.pos(d, d2, 0.0).endVertex();
        final double d3 = 6.283185307179586;
        for (int i = 0; i <= n; ++i) {
            final double d4 = d3 * i / n + Math.toRadians(180.0);
            RenderUtil2.bufferBuilder.pos(d + Math.sin(d4) * f, d2 + Math.cos(d4) * f, 0.0).endVertex();
        }
        RenderUtil2.tessellator.draw();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
    }
    
    public static void renderCircle(final BufferBuilder bufferBuilder, final Vec3d vec3d, final double d, final double d2, final Color color) {
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.shadeModel(7425);
        bufferBuilder.begin(3, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i < 361; ++i) {
            bufferBuilder.pos(vec3d.x + Math.sin(Math.toRadians(i)) * d - RenderUtil2.mc.getRenderManager().viewerPosX, vec3d.y + d2 - RenderUtil2.mc.getRenderManager().viewerPosY, vec3d.z + Math.cos(Math.toRadians(i)) * d - RenderUtil2.mc.getRenderManager().viewerPosZ).color(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, 1.0f).endVertex();
        }
        RenderUtil2.tessellator.draw();
        GlStateManager.enableCull();
        GlStateManager.enableAlpha();
        GlStateManager.shadeModel(7424);
    }
    
    static {
        RenderUtil2.tessellator = Tessellator.getInstance();
        RenderUtil2.bufferBuilder = RenderUtil2.tessellator.getBuffer();
        resolution = new ScaledResolution(RenderUtil2.mc);
    }
}
