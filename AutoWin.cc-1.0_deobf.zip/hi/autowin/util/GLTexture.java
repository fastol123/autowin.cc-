//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util;

public class GLTexture
{
    private final int id;
    
    public GLTexture(final int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
}
