//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.util.shader.impl;

import hi.autowin.util.mc.*;
import hi.autowin.util.shader.*;
import net.minecraft.client.shader.*;
import java.awt.*;
import hi.autowin.features.modules.client.*;
import net.minecraft.client.renderer.*;
import hi.autowin.util.paste.*;
import org.lwjgl.opengl.*;

public class GradientShader implements MC
{
    private static final ShaderUtil shader;
    private static Framebuffer framebuffer;
    
    public static void setupUniforms(final float step, final float speed, final Color color, final Color color2, final float opacity) {
        GradientShader.shader.setUniformi("texture", 0);
        GradientShader.shader.setUniformf("rgb", color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f);
        GradientShader.shader.setUniformf("rgb1", color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f);
        GradientShader.shader.setUniformf("step", 300.0f * step);
        GradientShader.shader.setUniformf("offset", (float)(System.currentTimeMillis() * (double)speed % (GradientShader.mc.displayWidth * GradientShader.mc.displayHeight) / 10.0));
        GradientShader.shader.setUniformf("mix", opacity);
    }
    
    public static void setup() {
        setup((float)Colors.INSTANCE.step.getValue(), (float)Colors.INSTANCE.speed.getValue(), Colors.INSTANCE.getGradient()[0], Colors.INSTANCE.getGradient()[1]);
    }
    
    public static void setup(final float opacity) {
        setup((float)Colors.INSTANCE.step.getValue(), (float)Colors.INSTANCE.speed.getValue(), Colors.INSTANCE.getGradient()[0], Colors.INSTANCE.getGradient()[1], opacity);
    }
    
    public static void setup(final float step, final float speed, final Color color, final Color color2) {
        setup(step, speed, color, color2, 1.0f);
    }
    
    public static void setup(final float step, final float speed, final Color color, final Color color2, final float opacity) {
        GlStateManager.enableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GradientShader.framebuffer = RenderUtil.createFrameBuffer(GradientShader.framebuffer);
        GradientShader.mc.getFramebuffer().bindFramebuffer(true);
        GradientShader.shader.init();
        setupUniforms(step, speed, color, color2, opacity);
        GL11.glBindTexture(3553, GradientShader.framebuffer.framebufferTexture);
    }
    
    public static void finish() {
        GradientShader.shader.unload();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.bindTexture(0);
        GL11.glEnable(3042);
    }
    
    static {
        shader = new ShaderUtil("textures/shaders/gradient.frag");
        GradientShader.framebuffer = new Framebuffer(1, 1, false);
    }
}
