//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.command.commands;

import hi.autowin.features.command.*;
import hi.autowin.*;
import com.mojang.realmsclient.gui.*;
import java.util.*;

public class HelpCommand extends Command
{
    public HelpCommand() {
        super("help");
    }
    
    public void execute(final String[] commands) {
        sendMessage("Commands: ");
        for (final Command command : Autowin.commandManager.getCommands()) {
            sendMessage(ChatFormatting.GRAY + Autowin.commandManager.getPrefix() + command.getName());
        }
    }
}
