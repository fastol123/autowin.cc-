//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.client;

import hi.autowin.features.modules.*;
import hi.autowin.util.misc.*;
import hi.autowin.features.setting.*;
import hi.autowin.features.command.*;
import hi.autowin.util.*;
import net.minecraft.entity.*;
import hi.autowin.*;
import java.util.*;
import hi.autowin.manager.*;
import hi.autowin.event.events.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class Notifications extends Module
{
    private static final String fileName = "autowin/utils/ModuleMessage_List.txt";
    private static final List<String> modules;
    private static Notifications INSTANCE;
    private final Timer timer;
    public Setting<Boolean> totemPops;
    public Setting<Integer> delay;
    public Setting<Boolean> clearOnLogout;
    public Setting<Boolean> moduleMessage;
    private final Setting<Boolean> readfile;
    public Setting<Boolean> list;
    public Setting<Boolean> visualRange;
    public Setting<Boolean> leaving;
    public Setting<Boolean> crash;
    public Timer totemAnnounce;
    private List<String> knownPlayers;
    private boolean check;
    
    public Notifications() {
        super("Display", "Sends Messages.", Category.CLIENT, true, false, false);
        this.timer = new Timer();
        this.totemPops = (Setting<Boolean>)this.register(new Setting("TotemPops", (T)false));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)2000, (T)0, (T)5000, v -> this.totemPops.getValue(), "Delays messages."));
        this.clearOnLogout = new Setting<Boolean>("LogoutClear", false);
        this.moduleMessage = (Setting<Boolean>)this.register(new Setting("ModuleMessage", (T)false));
        this.readfile = (Setting<Boolean>)this.register(new Setting("LoadFile", (T)false, v -> this.moduleMessage.getValue()));
        this.list = (Setting<Boolean>)this.register(new Setting("List", (T)false, v -> this.moduleMessage.getValue()));
        this.visualRange = (Setting<Boolean>)this.register(new Setting("VisualRange", (T)false));
        this.leaving = (Setting<Boolean>)this.register(new Setting("Leaving", (T)false, v -> this.visualRange.getValue()));
        this.crash = new Setting<Boolean>("Crash", false);
        this.totemAnnounce = new Timer();
        this.knownPlayers = new ArrayList<String>();
        this.setInstance();
    }
    
    public static Notifications getInstance() {
        if (Notifications.INSTANCE == null) {
            Notifications.INSTANCE = new Notifications();
        }
        return Notifications.INSTANCE;
    }
    
    public static void displayCrash(final Exception e) {
        Command.sendMessage("�cException caught: " + e.getMessage());
    }
    
    private void setInstance() {
        Notifications.INSTANCE = this;
    }
    
    @Override
    public void onLoad() {
        this.check = true;
        this.loadFile();
        this.check = false;
    }
    
    @Override
    public void onEnable() {
        this.knownPlayers = new ArrayList<String>();
        if (!this.check) {
            this.loadFile();
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.readfile.getValue()) {
            if (!this.check) {
                Command.sendMessage("Loading File...");
                this.timer.reset();
                this.loadFile();
            }
            this.check = true;
        }
        if (this.check && this.timer.passedMs(750L)) {
            this.readfile.setValue(false);
            this.check = false;
        }
        if (this.visualRange.getValue()) {
            final List<String> tickPlayerList = new ArrayList<String>();
            for (final Entity entity : Util.mc.world.playerEntities) {
                tickPlayerList.add(entity.getName());
            }
            if (tickPlayerList.size() > 0) {
                for (final String playerName : tickPlayerList) {
                    if (playerName.equals(Util.mc.player.getName())) {
                        continue;
                    }
                    if (!this.knownPlayers.contains(playerName)) {
                        this.knownPlayers.add(playerName);
                        if (Autowin.friendManager.isFriend(playerName)) {
                            Command.sendMessage("Player �a" + playerName + "�r" + " entered your visual range!");
                        }
                        else {
                            Command.sendMessage("Player �c" + playerName + "�r" + " entered your visual range!");
                        }
                        return;
                    }
                }
            }
            if (this.knownPlayers.size() > 0) {
                for (final String playerName : this.knownPlayers) {
                    if (!tickPlayerList.contains(playerName)) {
                        this.knownPlayers.remove(playerName);
                        if (this.leaving.getValue()) {
                            if (Autowin.friendManager.isFriend(playerName)) {
                                Command.sendMessage("Player �a" + playerName + "�r" + " left your visual range!");
                            }
                            else {
                                Command.sendMessage("Player �c" + playerName + "�r" + " left your visual range!");
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void loadFile() {
        final List<String> fileInput = FileManager.readTextFileAllLines("autowin/utils/ModuleMessage_List.txt");
        final Iterator<String> i = fileInput.iterator();
        Notifications.modules.clear();
        while (i.hasNext()) {
            final String s = i.next();
            if (!s.replaceAll("\\s", "").isEmpty()) {
                Notifications.modules.add(s);
            }
        }
    }
    
    @SubscribeEvent
    public void onToggleModule(final ClientEvent event) {
        if (!this.moduleMessage.getValue()) {
            return;
        }
        if (event.getStage() == 0) {
            final Module module = (Module)event.getFeature();
            if (!module.equals(this) && (Notifications.modules.contains(module.getDisplayName()) || !this.list.getValue())) {
                Command.sendMessage("�c" + module.getDisplayName() + " disabled.");
            }
        }
        if (event.getStage() == 1) {
            final Module module = (Module)event.getFeature();
            if (Notifications.modules.contains(module.getDisplayName()) || !this.list.getValue()) {
                Command.sendMessage("�a" + module.getDisplayName() + " enabled.");
            }
        }
    }
    
    static {
        modules = new ArrayList<String>();
        Notifications.INSTANCE = new Notifications();
    }
}
