//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.client;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import java.util.function.*;
import net.minecraft.util.*;

public class Capes extends Module
{
    private static Capes instance;
    public final Setting<Mode> mode;
    public final Setting<String> Name;
    
    public Capes() {
        super("Capes", "Capes", Category.CLIENT, true, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.Custom));
        this.Name = (Setting<String>)this.register(new Setting("CapeName", (T)"custom", (Predicate<T>)this::new0));
        Capes.instance = this;
    }
    
    public static Capes INSTANCE() {
        if (Capes.instance == null) {
            Capes.instance = new Capes();
        }
        return Capes.instance;
    }
    
    public ResourceLocation Cape() {
        if (this.mode.getValue() == Mode.Duck) {
            return new ResourceLocation("textures/capes/duck.png");
        }
        if (this.mode.getValue() == Mode.Lunar) {
            return new ResourceLocation("textures/capes/lunar.png");
        }
        if (this.mode.getValue() == Mode.OF) {
            return new ResourceLocation("textures/capes/of.png");
        }
        if (this.mode.getValue() == Mode.Moon) {
            return new ResourceLocation("textures/capes/moon.png");
        }
        if (this.mode.getValue() == Mode.Enderman) {
            return new ResourceLocation("textures/capes/enderman.png");
        }
        if (this.mode.getValue() == Mode.Panda) {
            return new ResourceLocation("textures/capes/panda.png");
        }
        if (this.mode.getValue() == Mode.Heart) {
            return new ResourceLocation("textures/capes/heart.png");
        }
        if (this.mode.getValue() == Mode.Purple) {
            return new ResourceLocation("textures/capes/purple.png");
        }
        if (this.mode.getValue() == Mode.Sad) {
            return new ResourceLocation("textures/capes/sad.png");
        }
        if (this.mode.getValue() == Mode.Shawchi) {
            return new ResourceLocation("textures/capes/shawchi.png");
        }
        if (this.mode.getValue() == Mode.Sad_two) {
            return new ResourceLocation("textures/capes/sad_two.png");
        }
        if (this.mode.getValue() == Mode.Custom) {
            return new ResourceLocation("textures/capes/" + this.Name.getValue() + ".png");
        }
        return null;
    }
    
    private boolean new0(final String string) {
        return this.mode.getValue() == Mode.Custom;
    }
    
    public enum Mode
    {
        Custom, 
        Duck, 
        Lunar, 
        OF, 
        Moon, 
        Enderman, 
        Panda, 
        Heart, 
        Purple, 
        Sad, 
        Shawchi, 
        Sad_two;
    }
}
