//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.client;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import java.awt.*;

public class Colors extends Module
{
    public static Colors INSTANCE;
    private final Setting<pages> pagesC;
    public Setting<Float> speed;
    public Setting<Float> step;
    public Setting<Integer> opacity;
    public Setting<Color> normalColor;
    public Setting<Integer> gradientRed1;
    public Setting<Integer> gradientGreen1;
    public Setting<Integer> gradientBlue1;
    public Setting<Integer> gradientRed2;
    public Setting<Integer> gradientGreen2;
    public Setting<Integer> gradientBlue2;
    
    public Colors() {
        super("Colors", "", Category.CLIENT, true, false, false);
        this.pagesC = (Setting<pages>)this.register(new Setting("Settings", (T)pages.Color));
        this.speed = (Setting<Float>)this.register(new Setting("Speed", (T)1.0f, (T)0.1f, (T)5.0f, v -> this.pagesC.getValue() == pages.Gradient));
        this.step = (Setting<Float>)this.register(new Setting("Step", (T)1.0f, (T)0.1f, (T)2.0f, v -> this.pagesC.getValue() == pages.Gradient));
        this.opacity = (Setting<Integer>)this.register(new Setting("Opacity", (T)100, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.normalColor = (Setting<Color>)this.register(new Setting("Color", (T)new Color(255, 0, 0), v -> this.pagesC.getValue() == pages.Color));
        this.gradientRed1 = (Setting<Integer>)this.register(new Setting("Red1", (T)68, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.gradientGreen1 = (Setting<Integer>)this.register(new Setting("Green1", (T)0, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.gradientBlue1 = (Setting<Integer>)this.register(new Setting("Blue1", (T)152, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.gradientRed2 = (Setting<Integer>)this.register(new Setting("Red2", (T)68, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.gradientGreen2 = (Setting<Integer>)this.register(new Setting("Green2", (T)255, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
        this.gradientBlue2 = (Setting<Integer>)this.register(new Setting("Blue2", (T)152, (T)0, (T)255, v -> this.pagesC.getValue() == pages.Gradient));
    }
    
    public Color getColor() {
        return new Color(this.normalColor.getValue().getRed(), this.normalColor.getValue().getGreen(), this.normalColor.getValue().getBlue());
    }
    
    public Color getColorsAlpha() {
        return new Color(this.normalColor.getValue().getRed(), this.normalColor.getValue().getGreen(), this.normalColor.getValue().getBlue(), this.normalColor.getValue().getAlpha());
    }
    
    public Color[] getGradient() {
        return new Color[] { new Color(this.gradientRed1.getValue(), this.gradientGreen1.getValue(), this.gradientBlue1.getValue()), new Color(this.gradientRed2.getValue(), this.gradientGreen2.getValue(), this.gradientBlue2.getValue()) };
    }
    
    static {
        Colors.INSTANCE = new Colors();
    }
    
    public enum pages
    {
        Color, 
        Gradient;
    }
}
