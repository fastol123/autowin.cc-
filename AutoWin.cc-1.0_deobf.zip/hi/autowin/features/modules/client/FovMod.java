//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.client;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import java.util.function.*;
import net.minecraft.client.settings.*;
import net.minecraftforge.client.event.*;
import net.minecraft.init.*;
import net.minecraftforge.fml.common.eventhandler.*;
import hi.autowin.event.events.*;

public class FovMod extends Module
{
    private static FovMod INSTANCE;
    private final Setting<Page> page;
    private final Setting<Boolean> customFov;
    private final Setting<Float> fov;
    private final Setting<Boolean> aspectRatio;
    private final Setting<Float> aspectFactor;
    private final Setting<Boolean> defaults;
    private final Setting<Float> sprint;
    private final Setting<Float> speed;
    
    public FovMod() {
        super("FovMod", "FovMod", Category.CLIENT, true, false, false);
        this.page = (Setting<Page>)this.register(new Setting("Settings", (T)Page.FOV));
        this.customFov = (Setting<Boolean>)this.register(new Setting("CustomFov", (T)Boolean.FALSE, (Predicate<T>)this::new0));
        this.fov = (Setting<Float>)this.register(new Setting("FOV", (T)120.0f, (T)10.0f, (T)180.0f, (Predicate<T>)this::new1));
        this.aspectRatio = (Setting<Boolean>)this.register(new Setting("AspectRatio", (T)Boolean.FALSE, (Predicate<T>)this::new2));
        this.aspectFactor = (Setting<Float>)this.register(new Setting("AspectFactor", (T)1.8f, (T)0.1f, (T)3.0f, (Predicate<T>)this::new3));
        this.defaults = (Setting<Boolean>)this.register(new Setting("Defaults", (T)Boolean.FALSE, (Predicate<T>)this::new4));
        this.sprint = (Setting<Float>)this.register(new Setting("SprintAdd", (T)1.15f, (T)1.0f, (T)2.0f, (Predicate<T>)this::new5));
        this.speed = (Setting<Float>)this.register(new Setting("SwiftnessAdd", (T)1.15f, (T)1.0f, (T)2.0f, (Predicate<T>)this::new6));
        this.setInstance();
    }
    
    public static FovMod INSTANCE() {
        if (FovMod.INSTANCE == null) {
            FovMod.INSTANCE = new FovMod();
        }
        return FovMod.INSTANCE;
    }
    
    private void setInstance() {
        FovMod.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (this.customFov.getValue()) {
            FovMod.mc.gameSettings.setOptionFloatValue(GameSettings.Options.FOV, (float)this.fov.getValue());
        }
        if (this.defaults.getValue()) {
            this.sprint.setValue(1.15f);
            this.speed.setValue(1.15f);
            this.defaults.setValue(false);
        }
    }
    
    @SubscribeEvent
    public void onFOVUpdate(final FOVUpdateEvent fOVUpdateEvent) {
        float f = 1.0f;
        if (fOVUpdateEvent.getEntity().isSprinting()) {
            f = this.sprint.getValue();
            if (fOVUpdateEvent.getEntity().isPotionActive(MobEffects.SPEED)) {
                f = this.speed.getValue();
            }
        }
        fOVUpdateEvent.setNewfov(f);
    }
    
    @SubscribeEvent
    public void onPerspectiveUpdate(final PerspectiveEvent perspectiveEvent) {
        if (this.aspectRatio.getValue()) {
            perspectiveEvent.setAspect((float)this.aspectFactor.getValue());
        }
    }
    
    private boolean new6(final Float f) {
        return this.page.getValue() == Page.ADVANCED;
    }
    
    private boolean new5(final Float f) {
        return this.page.getValue() == Page.ADVANCED;
    }
    
    private boolean new4(final Boolean bl) {
        return this.page.getValue() == Page.ADVANCED;
    }
    
    private boolean new3(final Float f) {
        return this.page.getValue() == Page.FOV && this.aspectRatio.getValue();
    }
    
    private boolean new2(final Boolean bl) {
        return this.page.getValue() == Page.FOV;
    }
    
    private boolean new1(final Float f) {
        return this.page.getValue() == Page.FOV && this.customFov.getValue();
    }
    
    private boolean new0(final Boolean bl) {
        return this.page.getValue() == Page.FOV;
    }
    
    static {
        FovMod.INSTANCE = new FovMod();
    }
    
    public enum Page
    {
        FOV, 
        ADVANCED;
    }
}
