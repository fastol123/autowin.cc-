//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.combat;

import hi.autowin.features.modules.*;
import hi.autowin.util.misc.*;
import hi.autowin.features.setting.*;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import java.util.function.*;
import java.util.stream.*;
import net.minecraft.entity.item.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import hi.autowin.util.*;
import com.mojang.realmsclient.gui.*;
import hi.autowin.features.command.*;
import hi.autowin.util.player.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.block.state.*;

public class Burrow extends Module
{
    private final Timer timer;
    Vec3d posCheck;
    public final Setting<Boolean> noToggle;
    private final Setting<Boolean> smartOffset;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> delay;
    private final Setting<Boolean> breakCrystal;
    private final Setting<Boolean> fristObby;
    private final Setting<Double> offsetZ;
    private final Setting<Boolean> bypass;
    private final Setting<Double> offsetX;
    private final Setting<Boolean> multiPlace;
    private static Burrow INSTANCE;
    private final Setting<Boolean> wait;
    private final Setting<Double> offsetY;
    public final Setting<Boolean> tpcenter;
    
    private void setInstance() {
        Burrow.INSTANCE = this;
    }
    
    public static boolean isAir(final BlockPos blockPos) {
        final Block block = Burrow.mc.world.getBlockState(blockPos).getBlock();
        return block instanceof BlockAir;
    }
    
    private static Double onTick2(final Entity entity) {
        return Burrow.mc.player.getDistanceSq(entity);
    }
    
    public static boolean fakeBBoxCheck(final EntityPlayer entityPlayer, final Vec3d vec3d, final boolean bl) {
        final Vec3d vec3d2 = entityPlayer.getPositionVector().add(vec3d);
        if (bl) {
            final Vec3d vec3d3 = entityPlayer.getPositionVector();
            return isAir(vec3d2.add(0.3, 0.0, 0.3)) && isAir(vec3d2.add(-0.3, 0.0, 0.3)) && isAir(vec3d2.add(0.3, 0.0, -0.3)) && isAir(vec3d2.add(-0.3, 0.0, 0.3)) && isAir(vec3d2.add(0.3, 1.8, 0.3)) && isAir(vec3d2.add(-0.3, 1.8, 0.3)) && isAir(vec3d2.add(0.3, 1.8, -0.3)) && isAir(vec3d2.add(-0.3, 1.8, 0.3)) && isAir(vec3d3.add(0.3, 2.8, 0.3)) && isAir(vec3d3.add(-0.3, 2.8, 0.3)) && isAir(vec3d3.add(-0.3, 2.8, -0.3)) && isAir(vec3d3.add(0.3, 2.8, -0.3));
        }
        return isAir(vec3d2.add(0.3, 0.0, 0.3)) && isAir(vec3d2.add(-0.3, 0.0, 0.3)) && isAir(vec3d2.add(0.3, 0.0, -0.3)) && isAir(vec3d2.add(-0.3, 0.0, 0.3)) && isAir(vec3d2.add(0.3, 1.8, 0.3)) && isAir(vec3d2.add(-0.3, 1.8, 0.3)) && isAir(vec3d2.add(0.3, 1.8, -0.3)) && isAir(vec3d2.add(-0.3, 1.8, 0.3));
    }
    
    public static BlockPos vec3toBlockPos(final Vec3d vec3d) {
        return new BlockPos(Math.floor(vec3d.x), (double)Math.round(vec3d.y), Math.floor(vec3d.z));
    }
    
    public Burrow() {
        super("SelfFill", "Burrow", Category.MISC, true, false, false);
        this.posCheck = null;
        this.noToggle = (Setting<Boolean>)this.register(new Setting("noDisable", (T)false));
        this.wait = (Setting<Boolean>)this.register(new Setting("WaitPlace", (T)true));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)3, (T)1, (T)20, (Predicate<T>)this::new0));
        this.bypass = (Setting<Boolean>)this.register(new Setting("Bypass", (T)true));
        this.timer = new Timer();
        this.breakCrystal = (Setting<Boolean>)this.register(new Setting("BreakCrystal", (T)true));
        this.onlyOnGround = (Setting<Boolean>)this.register(new Setting("OnlyOnGround", (T)true));
        this.multiPlace = (Setting<Boolean>)this.register(new Setting("MultiPlace", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.smartOffset = (Setting<Boolean>)this.register(new Setting("SmartOffset", (T)true));
        this.tpcenter = (Setting<Boolean>)this.register(new Setting("TPCenter", (T)false));
        this.offsetX = (Setting<Double>)this.register(new Setting("OffsetX", (T)(-7.0), (T)(-10.0), (T)10.0));
        this.offsetY = (Setting<Double>)this.register(new Setting("OffsetY", (T)(-7.0), (T)(-10.0), (T)10.0));
        this.offsetZ = (Setting<Double>)this.register(new Setting("OffsetZ", (T)(-7.0), (T)(-10.0), (T)10.0));
        this.fristObby = (Setting<Boolean>)this.register(new Setting("FristObby", (T)true));
        this.setInstance();
    }
    
    public BlockPos getOffsetBlock(final EntityPlayer entityPlayer) {
        final Vec3d vec3d = new Vec3d(entityPlayer.posX, entityPlayer.posY, entityPlayer.posZ);
        final RayTraceResult result = entityPlayer.world.rayTraceBlocks(vec3d, vec3d.add(new Vec3d(0.0, -1.0, 0.0)));
        if (result != null && result.typeOfHit == RayTraceResult.Type.BLOCK && this.canBur(result.getBlockPos())) {
            return result.getBlockPos();
        }
        return null;
    }
    
    private boolean canBur(final BlockPos blockPos) {
        return false;
    }
    
    @Override
    public void onTick() {
        if (this.posCheck != null) {
            if (Burrow.mc.player.getDistance(this.posCheck.x, this.posCheck.y, this.posCheck.z) > 1.0) {
                this.disable();
                return;
            }
        }
        else if (this.noToggle.getValue()) {
            this.disable();
            return;
        }
        final BlockPos blockPos = new BlockPos(Burrow.mc.player.posX, Burrow.mc.player.posY + 0.5, Burrow.mc.player.posZ);
        if ((checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, 0))) == null || !isAir(blockPos.add(0, 0, 0))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, 1))) == null || !isAir(blockPos.add(0, 0, 1))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, -1))) == null || !isAir(blockPos.add(0, 0, -1))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 0))) == null || !isAir(blockPos.add(1, 0, 0))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 0))) == null || !isAir(blockPos.add(-1, 0, 0))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 1))) == null || !isAir(blockPos.add(1, 0, 1))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, -1))) == null || !isAir(blockPos.add(-1, 0, -1))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, -1))) == null || !isAir(blockPos.add(1, 0, -1))) && (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 1))) == null || !isAir(blockPos.add(-1, 0, 1)))) {
            if (!this.noToggle.getValue()) {
                this.disable();
            }
            return;
        }
        if (this.wait.getValue()) {
            if (!this.timer.passedMs(this.delay.getValue() * 50)) {
                return;
            }
            this.timer.reset();
        }
        if (this.breakCrystal.getValue()) {
            for (final Entity entity : (List)Burrow.mc.world.loadedEntityList.stream().filter(Burrow::onTick1).sorted(Comparator.comparing((Function<? super T, ? extends Comparable>)Burrow::onTick2)).collect(Collectors.toList())) {
                if (entity instanceof EntityEnderCrystal) {
                    if (entity.getDistance((Entity)Burrow.mc.player) >= 2.5) {
                        continue;
                    }
                    Burrow.mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
                    Burrow.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
                    break;
                }
            }
        }
        final boolean bl = this.onlyOnGround.getValue();
        final boolean bl2 = !Burrow.mc.player.onGround;
        if (bl & (bl2 | Burrow.mc.world.getBlockState(getFlooredPosition((Entity)Burrow.mc.player).offset(EnumFacing.DOWN)).getBlock().equals(Blocks.AIR))) {
            return;
        }
        if (!Burrow.mc.world.isBlockLoaded(Burrow.mc.player.getPosition())) {
            return;
        }
        if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) == -1 && InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) == -1) {
            Command.sendMessage(ChatFormatting.RED + "Obsidian/Ender Chest ?");
            this.disable();
            return;
        }
        if (!fakeBBoxCheck((EntityPlayer)Burrow.mc.player, new Vec3d(0.0, 0.0, 0.0), true)) {
            boolean bl3 = false;
            boolean bl4 = false;
            if (!Burrow.mc.world.getBlockState(getFlooredPosition((Entity)Burrow.mc.player).offset(EnumFacing.UP, 2)).getBlock().equals(Blocks.AIR) || (Burrow.mc.world.getBlockState(blockPos.add(1, 2, 0)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(1, 0, 0)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(-1, 2, 0)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(-1, 0, 0)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(0, 2, 1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(0, 0, 1)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(0, 2, -1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(0, 0, -1)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(1, 2, 1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(1, 0, 1)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(1, 2, -1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(1, 0, -1)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(-1, 2, 1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(-1, 0, 1)) != null) || (Burrow.mc.world.getBlockState(blockPos.add(-1, 2, -1)).getBlock() != Blocks.AIR && checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos.add(-1, 0, -1)) != null)) {
                BlockPos blockPos2 = getFlooredPosition((Entity)Burrow.mc.player);
                if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos2) != null && !isAir(blockPos2) && (!isAir(blockPos2.offset(EnumFacing.DOWN)) || !this.bypass.getValue())) {
                    Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX) / 2.0, Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ) / 2.0, false));
                    Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX), Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ), false));
                }
                else {
                    for (final EnumFacing enumFacing : EnumFacing.VALUES) {
                        if (enumFacing != EnumFacing.UP) {
                            if (enumFacing != EnumFacing.DOWN) {
                                blockPos2 = getFlooredPosition((Entity)Burrow.mc.player).offset(enumFacing);
                                if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos2) != null && !isAir(blockPos2)) {
                                    if (!isAir(blockPos2.offset(EnumFacing.DOWN)) || !this.bypass.getValue()) {
                                        Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX) / 2.0, Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ) / 2.0, false));
                                        Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX), Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ), false));
                                        bl3 = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (!bl3) {
                        for (final EnumFacing enumFacing : EnumFacing.VALUES) {
                            if (enumFacing != EnumFacing.UP) {
                                if (enumFacing != EnumFacing.DOWN) {
                                    blockPos2 = getFlooredPosition((Entity)Burrow.mc.player).offset(enumFacing);
                                    if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), blockPos2) != null) {
                                        if (!isAir(blockPos2.offset(EnumFacing.DOWN)) || !this.bypass.getValue()) {
                                            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX) / 2.0, Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ) / 2.0, false));
                                            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX), Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ), false));
                                            bl4 = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        if (!bl4) {
                            for (final EnumFacing enumFacing : EnumFacing.VALUES) {
                                if (enumFacing != EnumFacing.UP) {
                                    if (enumFacing != EnumFacing.DOWN) {
                                        blockPos2 = getFlooredPosition((Entity)Burrow.mc.player).offset(enumFacing);
                                        if (isAir(blockPos2) && isAir(blockPos2.offset(EnumFacing.UP))) {
                                            if (!isAir(blockPos2.offset(EnumFacing.DOWN)) || !this.bypass.getValue()) {
                                                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX) / 2.0, Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ) / 2.0, false));
                                                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + (blockPos2.getX() + 0.5 - Burrow.mc.player.posX), Burrow.mc.player.posY + 0.2, Burrow.mc.player.posZ + (blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ), false));
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {
                final BlockPos blockPos2 = this.getOffsetBlock((EntityPlayer)Burrow.mc.player);
                if (blockPos2 == null) {
                    if (!this.noToggle.getValue()) {
                        this.disable();
                    }
                    return;
                }
                final double d = blockPos2.getX() + 0.5 - Burrow.mc.player.posX;
                final double d2 = blockPos2.getZ() + 0.5 - Burrow.mc.player.posZ;
                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + d * 0.25, Burrow.mc.player.posY + 0.419999986886978, Burrow.mc.player.posZ + d2 * 0.25, false));
                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + d * 0.5, Burrow.mc.player.posY + 0.7531999805212015, Burrow.mc.player.posZ + d2 * 0.5, false));
                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + d * 0.75, Burrow.mc.player.posY + 1.001335979112147, Burrow.mc.player.posZ + d2 * 0.75, false));
                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(blockPos2.getX() + 0.5, Burrow.mc.player.posY + 1.166109260938214, blockPos2.getZ() + 0.5, false));
            }
        }
        else {
            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX, Burrow.mc.player.posY + 0.419999986886978, Burrow.mc.player.posZ, false));
            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX, Burrow.mc.player.posY + 0.7531999805212015, Burrow.mc.player.posZ, false));
            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX, Burrow.mc.player.posY + 1.001335979112147, Burrow.mc.player.posZ, false));
            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX, Burrow.mc.player.posY + 1.166109260938214, Burrow.mc.player.posZ, false));
        }
        final int n = Burrow.mc.player.inventory.currentItem;
        if (this.fristObby.getValue()) {
            if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) != -1) {
                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)), false);
            }
            else if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) != -1) {
                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)), false);
            }
        }
        else if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)) != -1) {
            InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST)), false);
        }
        else if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) != -1) {
            InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)), false);
        }
        if (!this.multiPlace.getValue()) {
            if (isAir(blockPos)) {
                BlockUtil.placeBlock(blockPos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, 1))) != null && isAir(blockPos.add(0, 0, 1))) {
                BlockUtil.placeBlock(blockPos.add(0, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, -1))) != null && isAir(blockPos.add(0, 0, -1))) {
                BlockUtil.placeBlock(blockPos.add(0, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 0))) != null && isAir(blockPos.add(1, 0, 0))) {
                BlockUtil.placeBlock(blockPos.add(1, 0, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 0))) != null && isAir(blockPos.add(-1, 0, 0))) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 1))) != null && isAir(blockPos.add(1, 0, 1))) {
                BlockUtil.placeBlock(blockPos.add(1, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, -1))) != null && isAir(blockPos.add(-1, 0, -1))) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, -1))) != null && isAir(blockPos.add(1, 0, -1))) {
                BlockUtil.placeBlock(blockPos.add(1, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            else if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 1))) != null && isAir(blockPos.add(-1, 0, 1))) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
        }
        else {
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, 1))) != null) {
                BlockUtil.placeBlock(blockPos.add(0, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(0, 0, -1))) != null) {
                BlockUtil.placeBlock(blockPos.add(0, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 0))) != null) {
                BlockUtil.placeBlock(blockPos.add(1, 0, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 0))) != null) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, 1))) != null) {
                BlockUtil.placeBlock(blockPos.add(1, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, -1))) != null) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(1, 0, -1))) != null) {
                BlockUtil.placeBlock(blockPos.add(1, 0, -1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            if (checkEntity(EntityUtil.getVarOffsets(0, 0, 0), new BlockPos((Vec3i)blockPos.add(-1, 0, 1))) != null) {
                BlockUtil.placeBlock(blockPos.add(-1, 0, 1), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            }
            BlockUtil.placeBlock(blockPos.add(0, 0, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
        }
        Burrow.mc.player.inventory.currentItem = n;
        Burrow.mc.playerController.updateController();
        Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(new BlockPos(Burrow.mc.player.posX, Burrow.mc.player.posY - 1.0, Burrow.mc.player.posZ), EnumFacing.UP, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
        if (this.smartOffset.getValue()) {
            boolean bl5 = true;
            if (Burrow.mc.player.posY >= 3.0) {
                for (int i = -10; i < 10; ++i) {
                    if (i == -1) {
                        i = 4;
                    }
                    if (Burrow.mc.world.getBlockState(getFlooredPosition((Entity)Burrow.mc.player).add(0, i, 0)).getBlock().equals(Blocks.AIR) && Burrow.mc.world.getBlockState(getFlooredPosition((Entity)Burrow.mc.player).add(0, i + 1, 0)).getBlock().equals(Blocks.AIR)) {
                        final BlockPos blockPos3 = getFlooredPosition((Entity)Burrow.mc.player).add(0, i, 0);
                        Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(blockPos3.getX() + 0.3, (double)blockPos3.getY(), blockPos3.getZ() + 0.3, false));
                        bl5 = false;
                        break;
                    }
                }
            }
            if (bl5) {
                Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + this.offsetX.getValue(), Burrow.mc.player.posY + this.offsetY.getValue(), Burrow.mc.player.posZ + this.offsetZ.getValue(), false));
            }
        }
        else {
            Burrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(Burrow.mc.player.posX + this.offsetX.getValue(), Burrow.mc.player.posY + this.offsetY.getValue(), Burrow.mc.player.posZ + this.offsetZ.getValue(), false));
        }
        if (!this.wait.getValue()) {
            this.disable();
        }
        else if (!this.noToggle.getValue() && Burrow.mc.world.getBlockState(new BlockPos(Burrow.mc.player.posX, Burrow.mc.player.posY + 0.5, Burrow.mc.player.posZ)).getBlock() != Blocks.AIR) {
            this.disable();
        }
    }
    
    public static Burrow getInstance() {
        if (Burrow.INSTANCE == null) {
            Burrow.INSTANCE = new Burrow();
        }
        return Burrow.INSTANCE;
    }
    
    @Override
    public void onEnable() {
        this.posCheck = new Vec3d(Burrow.mc.player.posX, Burrow.mc.player.posY + 0.5, Burrow.mc.player.posZ);
    }
    
    public static BlockPos getPlayerPosFixY(final EntityPlayer entityPlayer) {
        return new BlockPos(Math.floor(entityPlayer.posX), (double)Math.round(entityPlayer.posY), Math.floor(entityPlayer.posZ));
    }
    
    private static boolean onTick1(final Entity entity) {
        return entity instanceof EntityEnderCrystal && !entity.isDead;
    }
    
    static Entity checkEntity(final Vec3d[] vec3dArray, final BlockPos blockPos) {
        Entity entity = null;
        for (final Vec3d vec3d : vec3dArray) {
            final BlockPos blockPos2 = new BlockPos((Vec3i)blockPos).add(vec3d.x, vec3d.y, vec3d.z);
            for (final Entity entity2 : Burrow.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(blockPos2))) {
                if (entity2 != Burrow.mc.player) {
                    continue;
                }
                if (entity != null) {
                    continue;
                }
                entity = entity2;
            }
        }
        return entity;
    }
    
    public static BlockPos vec3toBlockPos(final Vec3d vec3d, final boolean bl) {
        if (bl) {
            return new BlockPos(Math.floor(vec3d.x), Math.floor(vec3d.y), Math.floor(vec3d.z));
        }
        return new BlockPos(Math.floor(vec3d.x), (double)Math.round(vec3d.y), Math.floor(vec3d.z));
    }
    
    public static IBlockState getBlock(final Vec3d vec3d) {
        return Burrow.mc.world.getBlockState(vec3toBlockPos(vec3d));
    }
    
    public static boolean isAir(final Vec3d vec3d) {
        return Burrow.mc.world.getBlockState(vec3toBlockPos(vec3d, true)).getBlock().equals(Blocks.AIR);
    }
    
    public boolean canBur(final Vec3d vec3d) {
        final BlockPos blockPos = vec3toBlockPos(vec3d);
        return isAir(blockPos) && isAir(blockPos.offset(EnumFacing.UP)) && isAir(blockPos.offset(EnumFacing.UP, 2));
    }
    
    public static BlockPos getFlooredPosition(final Entity entity) {
        return new BlockPos(Math.floor(entity.posX), (double)Math.round(entity.posY), Math.floor(entity.posZ));
    }
    
    private boolean new0(final Integer n) {
        return this.wait.getValue();
    }
    
    static {
        Burrow.INSTANCE = new Burrow();
    }
}
