//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.combat;

import hi.autowin.features.modules.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import hi.autowin.util.*;
import hi.autowin.features.command.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.math.*;
import java.util.*;

public class InstantSelfFill extends Module
{
    private BlockPos originalPos;
    private int oldSlot;
    
    public InstantSelfFill() {
        super("InstantSelfFill", "does the thing i guess", Category.COMBAT, true, false, false);
        this.oldSlot = -1;
    }
    
    @Override
    public void onEnable() {
        this.originalPos = new BlockPos(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY, InstantSelfFill.mc.player.posZ);
        if (InstantSelfFill.mc.world.getBlockState(new BlockPos(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY, InstantSelfFill.mc.player.posZ)).getBlock().equals(Blocks.OBSIDIAN) || this.intersectsWithEntity(this.originalPos)) {
            this.toggle();
            return;
        }
        this.oldSlot = InstantSelfFill.mc.player.inventory.currentItem;
    }
    
    @Override
    public void onUpdate() {
        if (ItemUtil.findHotbarBlock(BlockObsidian.class) == -1) {
            Command.sendMessage("Can't find obsidian in hotbar!");
            this.toggle();
            return;
        }
        ItemUtil.switchToSlot(ItemUtil.findHotbarBlock(BlockObsidian.class));
        InstantSelfFill.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY + 0.41999998688698, InstantSelfFill.mc.player.posZ, true));
        InstantSelfFill.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY + 0.7531999805211997, InstantSelfFill.mc.player.posZ, true));
        InstantSelfFill.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY + 1.00133597911214, InstantSelfFill.mc.player.posZ, true));
        InstantSelfFill.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY + 1.16610926093821, InstantSelfFill.mc.player.posZ, true));
        ItemUtil.placeBlock(this.originalPos, EnumHand.MAIN_HAND, true, true, false);
        InstantSelfFill.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(InstantSelfFill.mc.player.posX, InstantSelfFill.mc.player.posY - 6.395812, InstantSelfFill.mc.player.posZ, false));
        ItemUtil.switchToSlot(this.oldSlot);
        Minecraft.getMinecraft().player.setSneaking(false);
        this.toggle();
    }
    
    private boolean intersectsWithEntity(final BlockPos pos) {
        for (final Entity entity : InstantSelfFill.mc.world.loadedEntityList) {
            if (entity.equals((Object)InstantSelfFill.mc.player)) {
                continue;
            }
            if (entity instanceof EntityItem) {
                continue;
            }
            if (new AxisAlignedBB(pos).intersects(entity.getEntityBoundingBox())) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void onDisable() {
        Minecraft.getMinecraft().player.setSneaking(false);
        super.onDisable();
    }
}
