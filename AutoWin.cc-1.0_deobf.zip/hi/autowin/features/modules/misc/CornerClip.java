//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.misc;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class CornerClip extends Module
{
    private static CornerClip INSTANCE;
    public final Setting<Integer> timeout;
    public final Setting<Boolean> disablee;
    public int disableThingy;
    
    public CornerClip() {
        super("Clip", "Phases slightly into the corner of a your surrounding to prevent crystal damage", Category.MISC, true, false, false);
        this.timeout = (Setting<Integer>)this.register(new Setting("Timeout", (T)5, (T)1, (T)10));
        this.disablee = (Setting<Boolean>)this.register(new Setting("Disable", (T)true));
        this.setInstance();
    }
    
    public static CornerClip getInstance() {
        if (CornerClip.INSTANCE == null) {
            CornerClip.INSTANCE = new CornerClip();
        }
        return CornerClip.INSTANCE;
    }
    
    private void setInstance() {
        CornerClip.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (nullCheck()) {
            return;
        }
        if (CornerClip.INSTANCE.movingByKeys()) {
            this.disable();
            return;
        }
        if (CornerClip.mc.world.getCollisionBoxes((Entity)CornerClip.mc.player, CornerClip.mc.player.getEntityBoundingBox().grow(0.01, 0.0, 0.01)).size() < 2) {
            CornerClip.mc.player.setPosition(roundToClosest(CornerClip.mc.player.posX, Math.floor(CornerClip.mc.player.posX) + 0.301, Math.floor(CornerClip.mc.player.posX) + 0.699), CornerClip.mc.player.posY, roundToClosest(CornerClip.mc.player.posZ, Math.floor(CornerClip.mc.player.posZ) + 0.301, Math.floor(CornerClip.mc.player.posZ) + 0.699));
        }
        else if (CornerClip.mc.player.ticksExisted % this.timeout.getValue() == 0) {
            CornerClip.mc.player.setPosition(CornerClip.mc.player.posX + MathHelper.clamp(roundToClosest(CornerClip.mc.player.posX, Math.floor(CornerClip.mc.player.posX) + 0.241, Math.floor(CornerClip.mc.player.posX) + 0.759) - CornerClip.mc.player.posX, -0.03, 0.03), CornerClip.mc.player.posY, CornerClip.mc.player.posZ + MathHelper.clamp(roundToClosest(CornerClip.mc.player.posZ, Math.floor(CornerClip.mc.player.posZ) + 0.241, Math.floor(CornerClip.mc.player.posZ) + 0.759) - CornerClip.mc.player.posZ, -0.03, 0.03));
            CornerClip.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(CornerClip.mc.player.posX, CornerClip.mc.player.posY, CornerClip.mc.player.posZ, true));
            CornerClip.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(roundToClosest(CornerClip.mc.player.posX, Math.floor(CornerClip.mc.player.posX) + 0.23, Math.floor(CornerClip.mc.player.posX) + 0.77), CornerClip.mc.player.posY, roundToClosest(CornerClip.mc.player.posZ, Math.floor(CornerClip.mc.player.posZ) + 0.23, Math.floor(CornerClip.mc.player.posZ) + 0.77), true));
            if (this.disablee.getValue()) {
                ++this.disableThingy;
            }
            else {
                this.disableThingy = 0;
            }
        }
        if (this.disableThingy >= 2 && this.disablee.getValue()) {
            this.disableThingy = 0;
            this.disable();
        }
    }
    
    private boolean movingByKeys() {
        return CornerClip.mc.gameSettings.keyBindForward.isKeyDown() || CornerClip.mc.gameSettings.keyBindBack.isKeyDown() || CornerClip.mc.gameSettings.keyBindLeft.isKeyDown() || CornerClip.mc.gameSettings.keyBindRight.isKeyDown();
    }
    
    public static double roundToClosest(final double num, final double low, final double high) {
        final double d1 = num - low;
        final double d2 = high - num;
        if (d2 > d1) {
            return low;
        }
        return high;
    }
    
    static {
        CornerClip.INSTANCE = new CornerClip();
    }
}
