//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.misc;

import hi.autowin.features.modules.*;
import hi.autowin.features.*;

public class NoEntityTrace extends Module
{
    private static NoEntityTrace INSTANCE;
    public boolean noTrace;
    
    public NoEntityTrace() {
        super("NoEntityTrace", "NoEntityTrace NoEntityTrace", Category.MISC, true, false, false);
        this.setInstance();
    }
    
    public static NoEntityTrace INSTANCE() {
        if (NoEntityTrace.INSTANCE == null) {
            NoEntityTrace.INSTANCE = new NoEntityTrace();
        }
        return NoEntityTrace.INSTANCE;
    }
    
    private void setInstance() {
        NoEntityTrace.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (Feature.fullNullCheck()) {
            return;
        }
        this.noTrace = true;
    }
    
    static {
        NoEntityTrace.INSTANCE = new NoEntityTrace();
    }
}
