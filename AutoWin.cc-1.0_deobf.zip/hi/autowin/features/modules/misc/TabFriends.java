//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.misc;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import net.minecraft.client.network.*;
import net.minecraft.scoreboard.*;
import hi.autowin.*;

public class TabFriends extends Module
{
    public static String color;
    public static TabFriends INSTANCE;
    public static Setting<Boolean> prefix;
    public Setting<FriendColor> mode;
    
    public TabFriends() {
        super("TabFriends", "TabFriends", Category.MISC, true, false, false);
        this.mode = (Setting<FriendColor>)this.register(new Setting("Color", (T)FriendColor.Green));
        TabFriends.prefix = (Setting<Boolean>)this.register(new Setting("Prefix", (T)true));
        TabFriends.INSTANCE = this;
    }
    
    public static String getPlayerName(final NetworkPlayerInfo networkPlayerInfoIn) {
        final String name = (networkPlayerInfoIn.getDisplayName() != null) ? networkPlayerInfoIn.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName((Team)networkPlayerInfoIn.getPlayerTeam(), networkPlayerInfoIn.getGameProfile().getName());
        if (!Autowin.friendManager.isFriend(name)) {
            return name;
        }
        if (TabFriends.prefix.getValue()) {
            return "\u00c2�7[" + TabFriends.color + "F\u00c2�7] " + TabFriends.color + name;
        }
        return TabFriends.color + name;
    }
    
    @Override
    public void onUpdate() {
        switch (this.mode.getValue()) {
            case DarkRed: {
                TabFriends.color = "\u00c2�4";
                break;
            }
            case Red: {
                TabFriends.color = "\u00c2�c";
                break;
            }
            case Gold: {
                TabFriends.color = "\u00c2�6";
                break;
            }
            case Yellow: {
                TabFriends.color = "\u00c2�e";
                break;
            }
            case DarkGreen: {
                TabFriends.color = "\u00c2�2";
                break;
            }
            case Green: {
                TabFriends.color = "\u00c2�a";
                break;
            }
            case Aqua: {
                TabFriends.color = "\u00c2�b";
                break;
            }
            case DarkAqua: {
                TabFriends.color = "\u00c2�3";
                break;
            }
            case DarkBlue: {
                TabFriends.color = "\u00c2�1";
                break;
            }
            case Blue: {
                TabFriends.color = "\u00c2�9";
                break;
            }
            case LightPurple: {
                TabFriends.color = "\u00c2�d";
                break;
            }
            case DarkPurple: {
                TabFriends.color = "\u00c2�5";
                break;
            }
            case Gray: {
                TabFriends.color = "\u00c2�7";
                break;
            }
            case DarkGray: {
                TabFriends.color = "\u00c2�8";
                break;
            }
            case Black: {
                TabFriends.color = "\u00c2�0";
                break;
            }
            case None: {
                TabFriends.color = "";
                break;
            }
        }
    }
    
    static {
        TabFriends.color = "";
    }
    
    private enum FriendColor
    {
        DarkRed, 
        Red, 
        Gold, 
        Yellow, 
        DarkGreen, 
        Green, 
        Aqua, 
        DarkAqua, 
        DarkBlue, 
        Blue, 
        LightPurple, 
        DarkPurple, 
        Gray, 
        DarkGray, 
        Black, 
        None;
    }
}
