//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.misc;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import net.minecraft.entity.player.*;
import hi.autowin.util.player.*;
import net.minecraft.entity.*;
import hi.autowin.*;
import java.util.function.*;
import hi.autowin.features.command.*;

public class PopLag extends Module
{
    private final Setting<Boolean> safety;
    private final Setting<Boolean> load;
    private final Setting<Boolean> friends;
    private static PopLag INSTANCE;
    private final Setting<Boolean> logDisable;
    private final Setting<Integer> health;
    public final Setting<String> msgString;
    private static String LAG_MESSAGE;
    
    public void onTotemPop(final EntityPlayer entityPlayer) {
        if (fullNullCheck() || entityPlayer == PopLag.mc.player || (this.safety.getValue() && EntityUtil.getHealth((Entity)PopLag.mc.player) <= this.health.getValue()) || (this.friends.getValue() && Autowin.friendManager.isFriend(entityPlayer.getName())) || this.isDisabled()) {
            return;
        }
        this.sendMessage(entityPlayer.getName());
    }
    
    private boolean new0(final Integer n) {
        return this.safety.getValue();
    }
    
    private void sendMessage(final String string) {
        PopLag.mc.player.sendChatMessage("/" + this.msgString.getValue() + " " + string + PopLag.LAG_MESSAGE);
    }
    
    public PopLag() {
        super("PopLag", "PopLag", Category.PLAYER, true, false, false);
        this.msgString = (Setting<String>)this.register(new Setting("msgString", (T)"minecraft:msg"));
        this.load = (Setting<Boolean>)this.register(new Setting("Load", (T)false));
        this.friends = (Setting<Boolean>)this.register(new Setting("NoFriends", (T)true));
        this.logDisable = (Setting<Boolean>)this.register(new Setting("DisableOnDc", (T)true));
        this.safety = (Setting<Boolean>)this.register(new Setting("Safety", (T)false));
        this.health = (Setting<Integer>)this.register(new Setting("StopHealth", (T)4, (T)1, (T)15, (Predicate<T>)this::new0));
        this.setInstance();
    }
    
    @Override
    public void onLogout() {
        if (!PopLag.mc.isSingleplayer() && this.isOn() && !fullNullCheck() && this.logDisable.getValue()) {
            this.disable();
        }
    }
    
    public static PopLag INSTANCE() {
        if (PopLag.INSTANCE == null) {
            PopLag.INSTANCE = new PopLag();
        }
        return PopLag.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        if (this.load.getValue()) {
            Command.sendMessage(PopLag.LAG_MESSAGE);
            this.load.setValue(false);
        }
    }
    
    private void setInstance() {
        PopLag.INSTANCE = this;
    }
    
    static {
        PopLag.INSTANCE = new PopLag();
        PopLag.LAG_MESSAGE = " \u0101\u0201\u0301\u0401\u0501\u0701\u0801\u0901\u0a01\u0b01\u0e01\u0f01\u1001\u1101\u1201\u1301\u1401\u1501\u1601\u1701\u1801\u1901\u1a01\u1b01\u1c01\u1d01\u1e01\u1f01 \u2101\u2201\u2301\u2401\u2501\u2701\u2801\u2901\u2a01\u2b01\u2c01\u2d01\u2e01\u2f01\u3001\u3201\u3301\u3401\u3501\u3601\u3701\u3801\u3901\u3a01\u3b01\u3c01\u3d01\u3e01\u3f01\u4001\u4101\u4201\u4301\u4401\u4501\u4601\u4701\u4801\u4901\u4a01\u4b01\u4c01\u4d01\u4e01\u4f01\u5001\u5101\u5201\u5301\u5401\u5501\u5601\u5701\u5801\u5901\u5a01\u5b01\u5c01\u5d01\u5e01\u5f01\u6001\u6101\u6201\u6301\u6401\u6501\u6601\u6701\u6801\u6901\u6a01\u6b01\u6c01\u6d01\u6e01\u6f01\u7001\u7101\u7201\u7301\u7401\u7501\u7601\u7701\u7801\u7901\u7a01\u7b01\u7c01\u7d01\u7e01\u7f01\u8001\u8101\u8201\u8301\u8401\u8501\u8601\u8701\u8801\u8901\u8a01\u8b01\u8c01\u8d01\u8e01\u8f01\u9001\u9101\u9201\u9301\u9401\u9501\u9601\u9701\u9801\u9901\u9a01\u9b01\u9c01\u9d01\u9e01\u9f01\ua001\ua101\ua201\ua301\ua401\ua501\ua601\ua701\ua801\ua901\uaa01\uab01\uac01\uad01\uae01\uaf01\ub001\ub101\ub201\ub301\ub401\ub501\ub601\ub701\ub801\ub901\uba01\ubb01\ubc01\ubd01";
    }
}
