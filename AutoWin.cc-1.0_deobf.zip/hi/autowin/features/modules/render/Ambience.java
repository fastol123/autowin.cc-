//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.render;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import net.minecraftforge.event.world.*;
import net.minecraftforge.fml.common.eventhandler.*;
import java.util.function.*;
import hi.autowin.event.events.*;
import hi.autowin.features.*;
import net.minecraft.network.play.server.*;

public class Ambience extends Module
{
    public final Setting<Boolean> timeChanger;
    private final Setting<Integer> time;
    
    @SubscribeEvent
    public void init(final WorldEvent worldEvent) {
        if (this.timeChanger.getValue()) {
            worldEvent.getWorld().setWorldTime((long)this.time.getValue());
        }
    }
    
    private boolean new3(final Integer n) {
        return this.timeChanger.getValue();
    }
    
    public Ambience() {
        super("TimeChanger", "Ambience", Module.Category.RENDER, true, false, false);
        this.timeChanger = (Setting<Boolean>)this.register(new Setting("TimeChanger", (T)Boolean.FALSE));
        this.time = (Setting<Integer>)this.register(new Setting("Time", (T)0, (T)0, (T)24000, (Predicate<T>)this::new3));
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive receive) {
        if (Feature.fullNullCheck()) {
            return;
        }
        if (receive.getPacket() instanceof SPacketTimeUpdate && this.timeChanger.getValue()) {
            receive.setCanceled(true);
        }
    }
}
