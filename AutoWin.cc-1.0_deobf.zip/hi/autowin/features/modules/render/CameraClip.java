//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.render;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;

public class CameraClip extends Module
{
    private static CameraClip INSTANCE;
    public final Setting<Double> distance;
    
    public CameraClip() {
        super("CameraClip", "CameraClip", Module.Category.RENDER, true, false, false);
        this.distance = (Setting<Double>)this.register(new Setting("Distance", (T)4.0, (T)(-10.0), (T)20.0));
        this.setInstance();
    }
    
    public static CameraClip Instance() {
        if (CameraClip.INSTANCE == null) {
            CameraClip.INSTANCE = new CameraClip();
        }
        return CameraClip.INSTANCE;
    }
    
    private void setInstance() {
        CameraClip.INSTANCE = this;
    }
    
    static {
        CameraClip.INSTANCE = new CameraClip();
    }
}
