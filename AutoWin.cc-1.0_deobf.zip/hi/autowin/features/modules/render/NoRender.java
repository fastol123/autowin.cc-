//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.render;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import hi.autowin.features.*;
import net.minecraft.init.*;
import hi.autowin.event.events.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.client.event.*;

public class NoRender extends Module
{
    public static NoRender INSTANCE;
    public final Setting<Boolean> armor;
    public final Setting<Boolean> fire;
    public final Setting<Boolean> blind;
    public final Setting<Boolean> nausea;
    public final Setting<Boolean> fog;
    public final Setting<Boolean> noWeather;
    public final Setting<Boolean> hurtCam;
    public final Setting<Boolean> totemPops;
    public final Setting<Boolean> blocks;
    
    public NoRender() {
        super("NoRender", "NoRender", Module.Category.MISC, true, false, false);
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)true));
        this.fire = (Setting<Boolean>)this.register(new Setting("Fire", (T)true));
        this.blind = (Setting<Boolean>)this.register(new Setting("Blind", (T)true));
        this.nausea = (Setting<Boolean>)this.register(new Setting("Nausea", (T)true));
        this.fog = (Setting<Boolean>)this.register(new Setting("Fog", (T)true));
        this.noWeather = (Setting<Boolean>)this.register(new Setting("Weather", (T)Boolean.TRUE, "AntiWeather"));
        this.hurtCam = (Setting<Boolean>)this.register(new Setting("HurtCam", (T)true));
        this.totemPops = (Setting<Boolean>)this.register(new Setting("TotemPop", (T)Boolean.TRUE, "Removes the Totem overlay."));
        this.blocks = (Setting<Boolean>)this.register(new Setting("Block", (T)true));
        this.setInstance();
    }
    
    public static NoRender INSTANCE() {
        if (NoRender.INSTANCE != null) {
            return NoRender.INSTANCE;
        }
        return NoRender.INSTANCE = new NoRender();
    }
    
    private void setInstance() {
        NoRender.INSTANCE = this;
    }
    
    public void onUpdate() {
        if (Feature.fullNullCheck()) {
            return;
        }
        if (this.blind.getValue() && NoRender.mc.player.isPotionActive(MobEffects.BLINDNESS)) {
            NoRender.mc.player.removePotionEffect(MobEffects.BLINDNESS);
        }
        if (!this.nausea.getValue()) {
            return;
        }
        if (this.noWeather.getValue()) {
            NoRender.mc.world.getWorldInfo().setRaining(false);
        }
        if (!NoRender.mc.player.isPotionActive(MobEffects.NAUSEA)) {
            return;
        }
        NoRender.mc.player.removePotionEffect(MobEffects.NAUSEA);
    }
    
    @SubscribeEvent
    public void NoRenderEventListener(final NoRenderEvent noRenderEvent) {
        if (noRenderEvent.getStage() == 0 && this.armor.getValue()) {
            noRenderEvent.setCanceled(true);
            return;
        }
        if (noRenderEvent.getStage() != 1) {
            return;
        }
        if (!this.hurtCam.getValue()) {
            return;
        }
        noRenderEvent.setCanceled(true);
    }
    
    @SubscribeEvent
    public void fog_density(final EntityViewRenderEvent.FogDensity fogDensity) {
        if (!this.fog.getValue()) {
            fogDensity.setDensity(0.0f);
            fogDensity.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void blockOverlayEventListener(final RenderBlockOverlayEvent renderBlockOverlayEvent) {
        if (!this.fire.getValue()) {
            return;
        }
        if (renderBlockOverlayEvent.getOverlayType() != RenderBlockOverlayEvent.OverlayType.FIRE) {
            return;
        }
        renderBlockOverlayEvent.setCanceled(true);
    }
    
    static {
        NoRender.INSTANCE = new NoRender();
    }
}
