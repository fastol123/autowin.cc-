//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.render;

import hi.autowin.features.modules.*;
import hi.autowin.features.setting.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import java.util.function.*;
import java.util.stream.*;
import hi.autowin.event.events.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.inventory.*;
import java.util.*;
import hi.autowin.util.*;
import net.minecraft.item.*;
import java.awt.*;
import net.minecraft.client.gui.*;

public class TargetHUD extends Module
{
    private final Setting<Integer> x;
    private final Setting<Integer> y;
    private final Setting<Integer> backgroundAlpha;
    EntityLivingBase target;
    
    public TargetHUD() {
        super("TargetHUD", "TargetHUD", Module.Category.RENDER, true, false, false);
        this.x = (Setting<Integer>)this.register(new Setting("X", (T)50, (T)0, (T)2000));
        this.y = (Setting<Integer>)this.register(new Setting("Y", (T)50, (T)0, (T)2000));
        this.backgroundAlpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)80, (T)0, (T)255));
        this.target = (EntityLivingBase)TargetHUD.mc.player;
    }
    
    private static double applyAsDouble(final EntityLivingBase entityLivingBase) {
        return entityLivingBase.getDistance((Entity)TargetHUD.mc.player);
    }
    
    private static boolean checkIsNotPlayer(final Entity entity) {
        return !entity.equals((Object)TargetHUD.mc.player);
    }
    
    public synchronized void onTick() {
        final LinkedList linkedList = new LinkedList();
        final Stream<Entity> stream = (Stream<Entity>)TargetHUD.mc.world.loadedEntityList.stream().filter(EntityPlayer.class::isInstance).filter(TargetHUD::checkIsNotPlayer).map(Entity.class::cast);
        EntityPlayer.class.getClass();
        final Stream<Entity> stream2 = stream.filter(EntityPlayer.class::isInstance).filter(TargetHUD::checkIsNotPlayer);
        EntityLivingBase.class.getClass();
        final Stream<EntityLivingBase> stream3 = stream2.map((Function<? super Entity, ? extends EntityLivingBase>)EntityLivingBase.class::cast).sorted(Comparator.comparingDouble((ToDoubleFunction<? super EntityLivingBase>)TargetHUD::applyAsDouble));
        linkedList.getClass();
        stream3.forEach(linkedList::add);
        this.target = (EntityLivingBase)(linkedList.isEmpty() ? TargetHUD.mc.player : ((EntityLivingBase)linkedList.get(0)));
        if (TargetHUD.mc.currentScreen instanceof GuiChat) {
            this.target = (EntityLivingBase)TargetHUD.mc.player;
        }
    }
    
    public synchronized void onRender2D(final Render2DEvent render2DEvent) {
        if (this.target != null && !this.target.isDead) {
            final FontRenderer fontRenderer = TargetHUD.mc.fontRenderer;
            final int n2 = (this.target.getHealth() / this.target.getMaxHealth() > 0.66f) ? -16711936 : ((this.target.getHealth() / this.target.getMaxHealth() > 0.33f) ? -26368 : -65536);
            GlStateManager.color(1.0f, 1.0f, 1.0f);
            GuiInventory.drawEntityOnScreen(this.x.getValue() + 15, this.y.getValue() + 32, 15, 1.0f, 1.0f, this.target);
            final LinkedList linkedList = new LinkedList();
            final LinkedList linkedList2 = new LinkedList();
            this.target.getArmorInventoryList().forEach(arg_0 -> onRender2D(linkedList2, arg_0));
            for (int n3 = linkedList2.size() - 1; n3 >= 0; --n3) {
                linkedList.add(linkedList2.get(n3));
            }
            int n3 = 0;
            switch (linkedList.size()) {
                case 0: {
                    if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 28, this.y.getValue() + 18);
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 43, this.y.getValue() + 18);
                        n3 += 45;
                        break;
                    }
                    if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                        break;
                    }
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand().isEmpty() ? this.target.getHeldItemOffhand() : this.target.getHeldItemMainhand(), this.x.getValue() + 28, this.y.getValue() + 18);
                    n3 += 30;
                    break;
                }
                case 1: {
                    n3 = 15;
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
                    if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 43, this.y.getValue() + 18);
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 58, this.y.getValue() + 18);
                        n3 += 45;
                        break;
                    }
                    if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                        break;
                    }
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand().isEmpty() ? this.target.getHeldItemOffhand() : this.target.getHeldItemMainhand(), this.x.getValue() + 43, this.y.getValue() + 18);
                    n3 += 30;
                    break;
                }
                case 2: {
                    n3 = 30;
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
                    if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 58, this.y.getValue() + 18);
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 73, this.y.getValue() + 18);
                        n3 += 45;
                        break;
                    }
                    if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                        break;
                    }
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand().isEmpty() ? this.target.getHeldItemOffhand() : this.target.getHeldItemMainhand(), this.x.getValue() + 58, this.y.getValue() + 18);
                    n3 += 30;
                    break;
                }
                case 3: {
                    n3 = 45;
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(2), this.x.getValue() + 58, this.y.getValue() + 18);
                    if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 73, this.y.getValue() + 18);
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 98, this.y.getValue() + 18);
                        n3 += 45;
                        break;
                    }
                    if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                        break;
                    }
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand().isEmpty() ? this.target.getHeldItemOffhand() : this.target.getHeldItemMainhand(), this.x.getValue() + 73, this.y.getValue() + 18);
                    n3 += 30;
                    break;
                }
                case 4: {
                    n3 = 60;
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(2), this.x.getValue() + 58, this.y.getValue() + 18);
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)linkedList.get(3), this.x.getValue() + 73, this.y.getValue() + 18);
                    if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 98, this.y.getValue() + 18);
                        Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 113, this.y.getValue() + 18);
                        n3 += 45;
                        break;
                    }
                    if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                        break;
                    }
                    Util.mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand().isEmpty() ? this.target.getHeldItemOffhand() : this.target.getHeldItemMainhand(), this.x.getValue() + 98, this.y.getValue() + 18);
                    n3 += 30;
                    break;
                }
            }
            int n4 = this.y.getValue() + 35;
            final int n5 = fontRenderer.getStringWidth(this.target.getName()) + 30;
            int n6 = (fontRenderer.getStringWidth(this.target.getName()) > n3) ? (this.x.getValue() + n5) : (this.x.getValue() + n3 + 30);
            final int n8 = this.x.getValue() - 2;
            final int intValue = this.y.getValue();
            n6 += 5;
            final int n9 = n6;
            n4 += 5;
            Gui.drawRect(n8, intValue, n9, n4, new Color(0, 0, 0, this.backgroundAlpha.getValue()).getRGB());
            final int n7 = (int)(this.target.getHealth() / this.target.getMaxHealth() * (n6 - this.x.getValue()));
            Gui.drawRect(this.x.getValue() - 2, n4 - 2, this.x.getValue() + n7, n4, n2);
            fontRenderer.drawString(this.target.getName(), (float)(this.x.getValue() + 30), (float)(this.y.getValue() + 8), new Color(255, 255, 255).getRGB(), true);
        }
    }
    
    private static void onRender2D(final List list, final ItemStack itemStack) {
        if (!itemStack.isEmpty()) {
            list.add(itemStack);
        }
    }
}
