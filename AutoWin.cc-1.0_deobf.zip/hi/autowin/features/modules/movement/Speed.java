//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.movement;

import hi.autowin.features.modules.*;

public class Speed extends Module
{
    public Speed() {
        super("Speed", "Speed.", Module.Category.MOVEMENT, true, false, false);
    }
    
    public String getDisplayInfo() {
        return "Strafe";
    }
}
