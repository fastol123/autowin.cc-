//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.movement;

import hi.autowin.features.modules.*;

public class Scaffold extends Module
{
    public Scaffold() {
        super("Scaffold", "Scaffold.", Module.Category.MOVEMENT, true, false, false);
    }
}
