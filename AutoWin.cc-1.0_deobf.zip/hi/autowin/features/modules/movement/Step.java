//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.movement;

import hi.autowin.features.modules.*;

public class Step extends Module
{
    public Step() {
        super("Step", "Step.", Module.Category.MOVEMENT, true, false, false);
    }
}
