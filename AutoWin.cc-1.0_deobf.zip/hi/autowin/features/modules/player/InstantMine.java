//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.modules.player;

import hi.autowin.features.modules.*;

public class InstantMine extends Module
{
    public InstantMine() {
        super("InstantMine", "breaking blocks", Module.Category.MISC, true, false, false);
    }
}
