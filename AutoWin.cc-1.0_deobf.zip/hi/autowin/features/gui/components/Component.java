//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.gui.components;

import hi.autowin.features.*;
import hi.autowin.features.gui.components.items.*;
import hi.autowin.features.modules.client.*;
import net.minecraft.client.gui.*;
import hi.autowin.util.Render.*;
import hi.autowin.*;
import hi.autowin.features.gui.*;
import java.util.*;
import net.minecraft.init.*;
import net.minecraft.client.audio.*;
import hi.autowin.features.gui.components.items.buttons.*;

public class Component extends Feature
{
    public static int[] counter1;
    private final ArrayList<Item> items;
    public boolean drag;
    private int x;
    private int y;
    private int x2;
    private int y2;
    private int width;
    private int height;
    private boolean open;
    private boolean hidden;
    
    public Component(final String string, final int n, final int n2, final boolean bl) {
        super(string);
        this.items = new ArrayList<Item>();
        this.hidden = false;
        this.x = n;
        this.y = n2;
        this.width = 100;
        this.height = 18;
        this.open = bl;
        this.setupItems();
    }
    
    public void setupItems() {
    }
    
    private void drag(final int n, final int n2) {
        if (!this.drag) {
            return;
        }
        this.x = this.x2 + n;
        this.y = this.y2 + n2;
    }
    
    public void drawScreen(final int n, final int n2, final float f) {
        this.drag(n, n2);
        Component.counter1 = new int[] { 1 };
        final float f2 = this.open ? (this.getTotalItemHeight() - 2.0f) : 0.0f;
        final int n3 = ColorUtil.toARGB(ClickGui.getInstance().topRed.getValue(), ClickGui.getInstance().topGreen.getValue(), ClickGui.getInstance().topBlue.getValue(), 255);
        Gui.drawRect(this.x, this.y - 1, this.x + this.width, this.y + this.height - 6, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB() : n3);
        if (this.open) {
            RenderUtil.drawRect((float)this.x, this.y + 12.5f, (float)(this.x + this.width), this.y + this.height + 1 + f2, -2013265920);
        }
        Autowin.textManager.drawString("\u2022 \u2022 \u2022", (float)(this.x + this.width - 19), this.y + 1.0f, 16777215, true);
        Autowin.textManager.drawStringWithShadow(this.getName(), this.x + 3.0f, this.y - 4.0f - AutowinGui.getClickGui().getTextOffset(), -1);
        if (this.open) {
            float f3 = this.getY() + this.getHeight() - 3.0f;
            for (final Item item : this.getItems()) {
                ++Component.counter1[0];
                if (item.isHidden()) {
                    continue;
                }
                item.setLocation(this.x + 2.0f, f3);
                item.setWidth(this.getWidth() - 4);
                item.drawScreen(n, n2, f);
                f3 += item.getHeight() + 1.5f;
            }
        }
    }
    
    public void mouseClicked(final int n, final int n2, final int n3) {
        if (n3 == 0 && this.isHovering(n, n2)) {
            this.x2 = this.x - n;
            this.y2 = this.y - n2;
            AutowinGui.getClickGui().getComponents().forEach(component -> {
                if (component.drag) {
                    component.drag = false;
                }
                return;
            });
            this.drag = true;
            return;
        }
        if (n3 == 1 && this.isHovering(n, n2)) {
            this.open = !this.open;
            Component.mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0f));
            return;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseClicked(n, n2, n3));
    }
    
    public void mouseReleased(final int n, final int n2, final int n3) {
        if (n3 == 0) {
            this.drag = false;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseReleased(n, n2, n3));
    }
    
    public void onKeyTyped(final char c, final int n) {
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.onKeyTyped(c, n));
    }
    
    public void addButton(final Button button) {
        this.items.add(button);
    }
    
    public int getX() {
        return this.x;
    }
    
    public void setX(final int n) {
        this.x = n;
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(final int n) {
        this.y = n;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public void setWidth(final int n) {
        this.width = n;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int n) {
        this.height = n;
    }
    
    public boolean isHidden() {
        return this.hidden;
    }
    
    public void setHidden(final boolean bl) {
        this.hidden = bl;
    }
    
    public boolean isOpen() {
        return this.open;
    }
    
    public final ArrayList<Item> getItems() {
        return this.items;
    }
    
    private boolean isHovering(final int n, final int n2) {
        return n >= this.getX() && n <= this.getX() + this.getWidth() && n2 >= this.getY() && n2 <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
    }
    
    private float getTotalItemHeight() {
        float f = 0.0f;
        for (final Item item : this.getItems()) {
            f += item.getHeight() + 1.5f;
        }
        return f;
    }
    
    static {
        Component.counter1 = new int[] { 1 };
    }
}
