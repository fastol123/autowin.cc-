//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.gui.components.items.buttons;

import hi.autowin.features.setting.*;
import hi.autowin.util.Render.*;
import hi.autowin.*;
import hi.autowin.features.modules.client.*;
import com.mojang.realmsclient.gui.*;
import hi.autowin.features.gui.*;
import hi.autowin.features.gui.components.*;
import java.util.*;
import org.lwjgl.input.*;

public class Slider extends Button
{
    private final Number min;
    private final Number max;
    private final int difference;
    public Setting setting;
    
    public Slider(final Setting setting) {
        super(setting.getName());
        this.setting = setting;
        this.min = setting.getMin();
        this.max = setting.getMax();
        this.difference = this.max.intValue() - this.min.intValue();
        this.width = 15;
    }
    
    public void drawScreen(final int n, final int n2, final float f) {
        this.dragSetting(n, n2);
        RenderUtil.drawRect(this.x, this.y, this.x + this.width + 7.4f, this.y + this.height - 0.5f, this.isHovering(n, n2) ? -2007673515 : 290805077);
        RenderUtil.drawRect(this.x, this.y, (this.setting.getValue().floatValue() <= this.min.floatValue()) ? this.x : (this.x + (this.width + 7.4f) * this.partialMultiplier()), this.y + this.height - 0.5f, this.isHovering(n, n2) ? Autowin.colorManager.getColorWithAlpha(Autowin.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue()) : Autowin.colorManager.getColorWithAlpha(Autowin.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue()));
        Autowin.textManager.drawStringWithShadow(this.getName() + " " + ChatFormatting.GRAY + ((this.setting.getValue() instanceof Float) ? this.setting.getValue() : this.setting.getValue().doubleValue()), this.x + 2.3f, this.y - 1.7f - AutowinGui.getClickGui().getTextOffset(), -1);
    }
    
    public void mouseClicked(final int n, final int n2, final int n3) {
        super.mouseClicked(n, n2, n3);
        if (this.isHovering(n, n2)) {
            this.setSettingFromX(n);
        }
    }
    
    public boolean isHovering(final int n, final int n2) {
        for (final Component component : AutowinGui.getClickGui().getComponents()) {
            if (!component.drag) {
                continue;
            }
            return false;
        }
        return n >= this.getX() && n <= this.getX() + this.getWidth() + 8.0f && n2 >= this.getY() && n2 <= this.getY() + this.height;
    }
    
    public void update() {
        this.setHidden(!this.setting.isVisible());
    }
    
    private void dragSetting(final int n, final int n2) {
        if (this.isHovering(n, n2) && Mouse.isButtonDown(0)) {
            this.setSettingFromX(n);
        }
    }
    
    public int getHeight() {
        return 14;
    }
    
    private void setSettingFromX(final int n) {
        final float f = (n - this.x) / (this.width + 7.4f);
        if (this.setting.getValue() instanceof Double) {
            final double d = this.setting.getMin() + this.difference * f;
            this.setting.setValue(Math.round(10.0 * d) / 10.0);
        }
        else if (this.setting.getValue() instanceof Float) {
            final float f2 = this.setting.getMin() + this.difference * f;
            this.setting.setValue(Math.round(10.0f * f2) / 10.0f);
        }
        else if (this.setting.getValue() instanceof Integer) {
            this.setting.setValue(this.setting.getMin() + (int)(this.difference * f));
        }
    }
    
    private float middle() {
        return this.max.floatValue() - this.min.floatValue();
    }
    
    private float part() {
        return this.setting.getValue().floatValue() - this.min.floatValue();
    }
    
    private float partialMultiplier() {
        return this.part() / this.middle();
    }
}
