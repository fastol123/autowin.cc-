//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.gui.components.items.buttons;

import hi.autowin.features.gui.components.items.*;
import hi.autowin.*;
import hi.autowin.features.modules.client.*;
import hi.autowin.util.Render.*;
import hi.autowin.features.gui.*;
import net.minecraft.init.*;
import net.minecraft.client.audio.*;
import hi.autowin.features.gui.components.*;
import java.util.*;

public class Button extends Item
{
    private boolean state;
    
    public Button(final String string) {
        super(string);
        this.height = 15;
    }
    
    @Override
    public void drawScreen(final int n, final int n2, final float f) {
        RenderUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height - 0.5f, this.getState() ? (this.isHovering(n, n2) ? Autowin.colorManager.getColorWithAlpha(Autowin.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue()) : Autowin.colorManager.getColorWithAlpha(Autowin.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue())) : (this.isHovering(n, n2) ? -2007673515 : 894784853));
        Autowin.textManager.drawStringWithShadow(this.getName(), this.x + 2.3f, this.y - 2.0f - AutowinGui.getClickGui().getTextOffset(), this.getState() ? -1 : -5592406);
    }
    
    @Override
    public void mouseClicked(final int n, final int n2, final int n3) {
        if (n3 == 0 && this.isHovering(n, n2)) {
            this.onMouseClick();
        }
    }
    
    public void onMouseClick() {
        this.state = !this.state;
        this.toggle();
        Button.mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }
    
    public void toggle() {
    }
    
    public boolean getState() {
        return this.state;
    }
    
    @Override
    public int getHeight() {
        return 14;
    }
    
    public boolean isHovering(final int n, final int n2) {
        for (final Component component : AutowinGui.getClickGui().getComponents()) {
            if (!component.drag) {
                continue;
            }
            return false;
        }
        return n >= this.getX() && n <= this.getX() + this.getWidth() && n2 >= this.getY() && n2 <= this.getY() + this.height;
    }
}
