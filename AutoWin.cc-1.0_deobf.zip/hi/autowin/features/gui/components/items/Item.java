//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.gui.components.items;

import hi.autowin.features.*;

public class Item extends Feature
{
    protected float x;
    protected float y;
    protected int width;
    protected int height;
    private boolean hidden;
    
    public Item(final String string) {
        super(string);
    }
    
    public void setLocation(final float f, final float f2) {
        this.x = f;
        this.y = f2;
    }
    
    public void drawScreen(final int n, final int n2, final float f) {
    }
    
    public void mouseClicked(final int n, final int n2, final int n3) {
    }
    
    public void mouseReleased(final int n, final int n2, final int n3) {
    }
    
    public void update() {
    }
    
    public void onKeyTyped(final char c, final int n) {
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public void setWidth(final int n) {
        this.width = n;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int n) {
        this.height = n;
    }
    
    public boolean isHidden() {
        return this.hidden;
    }
    
    public boolean setHidden(final boolean bl) {
        return this.hidden = bl;
    }
}
