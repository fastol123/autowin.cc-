//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.features.gui;

import net.minecraft.client.gui.*;
import hi.autowin.features.gui.components.*;
import hi.autowin.*;
import hi.autowin.features.modules.*;
import hi.autowin.features.gui.components.items.buttons.*;
import hi.autowin.features.*;
import java.util.function.*;
import hi.autowin.features.gui.components.items.*;
import java.util.*;
import org.lwjgl.input.*;
import java.io.*;

public class AutowinGui extends GuiScreen
{
    private static AutowinGui autowinGui;
    private static AutowinGui INSTANCE;
    private final ArrayList<Component> components;
    
    public AutowinGui() {
        this.components = new ArrayList<Component>();
        this.setInstance();
        this.load();
    }
    
    public static AutowinGui getInstance() {
        if (AutowinGui.INSTANCE == null) {
            AutowinGui.INSTANCE = new AutowinGui();
        }
        return AutowinGui.INSTANCE;
    }
    
    public static AutowinGui getClickGui() {
        return getInstance();
    }
    
    private void setInstance() {
        AutowinGui.INSTANCE = this;
    }
    
    private void load() {
        int n = -100;
        Autowin.moduleManager.getCategories().stream().sorted(Comparator.comparingInt(category -> category.getName().length())).forEach(category -> {});
        for (final Module.Category category2 : Autowin.moduleManager.getCategories()) {
            final ArrayList<Component> components = this.components;
            final String name = category2.getName();
            n += 102;
            components.add(new Component(name, n, 4, true) {
                @Override
                public void setupItems() {
                    AutowinGui$1.counter1 = new int[] { 1 };
                    Autowin.moduleManager.getModulesByCategory(category2).forEach(module -> {
                        if (!module.hidden) {
                            this.addButton(new ModuleButton(module));
                        }
                    });
                }
            });
        }
        this.components.forEach(component -> component.getItems().sort(Comparator.comparing((Function<? super Item, ? extends Comparable>)Feature::getName)));
    }
    
    public void updateModule(final Module module) {
        for (final Component component : this.components) {
            for (final Item item : component.getItems()) {
                if (!(item instanceof ModuleButton)) {
                    continue;
                }
                final ModuleButton moduleButton = (ModuleButton)item;
                final Module module2 = moduleButton.getModule();
                if (module == null) {
                    continue;
                }
                if (!module.equals(module2)) {
                    continue;
                }
                moduleButton.initSettings();
            }
        }
    }
    
    public void drawScreen(final int n, final int n2, final float f) {
        this.checkMouseWheel();
        this.drawDefaultBackground();
        this.components.forEach(component -> component.drawScreen(n, n2, f));
    }
    
    public void mouseClicked(final int n, final int n2, final int n3) {
        this.components.forEach(component -> component.mouseClicked(n, n2, n3));
    }
    
    public void mouseReleased(final int n, final int n2, final int n3) {
        this.components.forEach(component -> component.mouseReleased(n, n2, n3));
    }
    
    public boolean doesGuiPauseGame() {
        return false;
    }
    
    public final ArrayList<Component> getComponents() {
        return this.components;
    }
    
    public void checkMouseWheel() {
        final int n = Mouse.getDWheel();
        if (n < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        }
        else if (n > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
    }
    
    public int getTextOffset() {
        return -6;
    }
    
    public Component getComponentByName(final String string) {
        for (final Component component : this.components) {
            if (!component.getName().equalsIgnoreCase(string)) {
                continue;
            }
            return component;
        }
        return null;
    }
    
    public void keyTyped(final char c, final int n) throws IOException {
        super.keyTyped(c, n);
        this.components.forEach(component -> component.onKeyTyped(c, n));
    }
    
    static {
        AutowinGui.INSTANCE = new AutowinGui();
    }
}
