//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.mixin;

import net.minecraftforge.fml.relauncher.*;
import hi.autowin.*;
import org.spongepowered.asm.launch.*;
import org.spongepowered.asm.mixin.*;
import java.util.*;

public class AutowinLoader implements IFMLLoadingPlugin
{
    private static boolean isObfuscatedEnvironment;
    
    public AutowinLoader() {
        Autowin.LOGGER.info("\n\nLoading mixins by fag");
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.autowin.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
        Autowin.LOGGER.info(MixinEnvironment.getDefaultEnvironment().getObfuscationContext());
    }
    
    public String[] getASMTransformerClass() {
        return new String[0];
    }
    
    public String getModContainerClass() {
        return null;
    }
    
    public String getSetupClass() {
        return null;
    }
    
    public void injectData(final Map<String, Object> data) {
        AutowinLoader.isObfuscatedEnvironment = data.get("runtimeDeobfuscationEnabled");
    }
    
    public String getAccessTransformerClass() {
        return null;
    }
    
    static {
        AutowinLoader.isObfuscatedEnvironment = false;
    }
}
