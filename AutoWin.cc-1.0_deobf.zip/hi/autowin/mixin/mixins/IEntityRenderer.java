//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.mixin.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.renderer.*;
import org.spongepowered.asm.mixin.gen.*;

@Mixin({ EntityRenderer.class })
public interface IEntityRenderer
{
    @Invoker("setupCameraTransform")
    void setupCamera(final float p0, final int p1);
    
    @Invoker("renderHand")
    void renderHand(final float p0, final int p1);
}
