//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.mixin.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.renderer.*;
import net.minecraft.item.*;
import net.minecraft.client.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import com.google.common.base.*;
import hi.autowin.features.modules.misc.*;
import java.util.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import hi.autowin.features.modules.render.*;
import org.spongepowered.asm.mixin.injection.*;
import net.minecraft.init.*;
import hi.autowin.event.events.*;
import net.minecraftforge.common.*;
import net.minecraftforge.fml.common.eventhandler.*;
import org.lwjgl.util.glu.*;

@Mixin({ EntityRenderer.class })
public class MixinEntityRenderer
{
    public ItemStack itemActivationItem;
    final Minecraft mc;
    
    public MixinEntityRenderer() {
        this.mc = Minecraft.getMinecraft();
    }
    
    @Redirect(method = { "getMouseOver" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/WorldClient;getEntitiesInAABBexcluding(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;Lcom/google/common/base/Predicate;)Ljava/util/List;"))
    public List getEntitiesInAABBexcluding(final WorldClient worldClient, final Entity entity, final AxisAlignedBB axisAlignedBB, final Predicate predicate) {
        if (NoEntityTrace.INSTANCE().isOn()) {
            return new ArrayList();
        }
        return worldClient.getEntitiesInAABBexcluding(entity, axisAlignedBB, predicate);
    }
    
    @Inject(method = { "hurtCameraEffect" }, at = { @At("HEAD") }, cancellable = true)
    public void hurtCameraEffect(final float f, final CallbackInfo callbackInfo) {
        if (NoRender.INSTANCE.isEnabled() && (boolean)NoRender.INSTANCE().hurtCam.getValue()) {
            callbackInfo.cancel();
        }
    }
    
    @ModifyVariable(method = { "orientCamera" }, ordinal = 3, at = @At(value = "STORE", ordinal = 0), require = 1)
    public double changeCameraDistanceHook(final double d) {
        if (CameraClip.Instance().isEnabled()) {
            return (double)CameraClip.Instance().distance.getValue();
        }
        return d;
    }
    
    @Inject(method = { "renderItemActivation" }, at = { @At("HEAD") }, cancellable = true)
    public void renderItemActivationHook(final CallbackInfo callbackInfo) {
        if (this.itemActivationItem != null && NoRender.INSTANCE().isOn() && (boolean)NoRender.INSTANCE().totemPops.getValue() && this.itemActivationItem.getItem() == Items.TOTEM_OF_UNDYING) {
            callbackInfo.cancel();
        }
    }
    
    @ModifyVariable(method = { "orientCamera" }, ordinal = 7, at = @At(value = "STORE", ordinal = 0), require = 1)
    public double orientCameraHook(final double d) {
        if (CameraClip.Instance().isEnabled()) {
            return (double)CameraClip.Instance().distance.getValue();
        }
        return d;
    }
    
    @Redirect(method = { "setupCameraTransform" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onSetupCameraTransform(final float f, final float f2, final float f3, final float f4) {
        final PerspectiveEvent perspectiveEvent = new PerspectiveEvent(this.mc.displayWidth / (float)this.mc.displayHeight);
        MinecraftForge.EVENT_BUS.post((Event)perspectiveEvent);
        Project.gluPerspective(f, perspectiveEvent.getAspect(), f3, f4);
    }
    
    @Redirect(method = { "renderWorldPass" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onRenderWorldPass(final float f, final float f2, final float f3, final float f4) {
        final PerspectiveEvent perspectiveEvent = new PerspectiveEvent(this.mc.displayWidth / (float)this.mc.displayHeight);
        MinecraftForge.EVENT_BUS.post((Event)perspectiveEvent);
        Project.gluPerspective(f, perspectiveEvent.getAspect(), f3, f4);
    }
    
    @Redirect(method = { "renderCloudsCheck" }, at = @At(value = "INVOKE", target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"))
    private void onRenderCloudsCheck(final float f, final float f2, final float f3, final float f4) {
        final PerspectiveEvent perspectiveEvent = new PerspectiveEvent(this.mc.displayWidth / (float)this.mc.displayHeight);
        MinecraftForge.EVENT_BUS.post((Event)perspectiveEvent);
        Project.gluPerspective(f, perspectiveEvent.getAspect(), f3, f4);
    }
}
