//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.event.events;

import hi.autowin.event.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

@Cancelable
public class PlayerDamageBlockEvent extends EventStage
{
    public final BlockPos pos;
    public final EnumFacing facing;
    
    public PlayerDamageBlockEvent(final int n, final BlockPos blockPos, final EnumFacing enumFacing) {
        super(n);
        this.pos = blockPos;
        this.facing = enumFacing;
    }
    
    public final BlockPos getPos() {
        return this.pos;
    }
}
