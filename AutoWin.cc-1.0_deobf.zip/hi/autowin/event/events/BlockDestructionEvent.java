//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\Shadow_Fiend\Documents\Decompiler\mappings"!

//Decompiled by Procyon!

package hi.autowin.event.events;

import hi.autowin.event.*;
import net.minecraft.util.math.*;

public class BlockDestructionEvent extends EventStage
{
    BlockPos nigger;
    
    public BlockDestructionEvent(BlockPos nigger) {
        nigger = nigger;
    }
    
    public BlockPos getBlockPos() {
        return this.nigger;
    }
}
